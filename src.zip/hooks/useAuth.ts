import { useState, useEffect } from 'react';

interface User {
  id: string;
  username: string;
  role: 'admin' | 'psychologist';
  full_name?: string;
  email?: string;
  loginTime: string;
}

interface Psychologist {
  id: string;
  username: string;
  full_name: string;
  email: string;
  phone?: string;
  license_number?: string;
  specialization?: string;
  status: 'active' | 'inactive';
  created_at: string;
  updated_at: string;
  created_by: string; // admin who created this psychologist
}

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const userStr = localStorage.getItem('psicoManager_user');
    if (userStr) {
      try {
        const userData = JSON.parse(userStr);
        setUser(userData);
      } catch (error) {
        localStorage.removeItem('psicoManager_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = (username: string, password: string): Promise<User> => {
    return new Promise((resolve, reject) => {
      // Default admin credentials
      if (username === 'admin' && password === 'admin123') {
        const adminUser: User = {
          id: 'admin_001',
          username: 'admin',
          role: 'admin',
          full_name: 'Administrador General',
          email: 'admin@psicomanager.com',
          loginTime: new Date().toISOString()
        };
        
        localStorage.setItem('psicoManager_user', JSON.stringify(adminUser));
        setUser(adminUser);
        resolve(adminUser);
        return;
      }

      // Demo psychologist credentials
      if (username === 'psicologo1' && password === 'psi123') {
        const psychologistUser: User = {
          id: 'psy_demo_001',
          username: 'psicologo1',
          role: 'psychologist',
          full_name: 'Dr. María González',
          email: 'maria.gonzalez@psicomanager.com',
          loginTime: new Date().toISOString()
        };
        
        localStorage.setItem('psicoManager_user', JSON.stringify(psychologistUser));
        setUser(psychologistUser);
        resolve(psychologistUser);
        return;
      }

      // Check psychologists in localStorage
      const psychologists = getPsychologists();
      const psychologist = psychologists.find(p => 
        p.username === username && 
        p.status === 'active'
      );

      if (psychologist) {
        // For demo purposes, accept any password for psychologists
        // In production, you would verify the hashed password
        const psychologistUser: User = {
          id: psychologist.id,
          username: psychologist.username,
          role: 'psychologist',
          full_name: psychologist.full_name,
          email: psychologist.email,
          loginTime: new Date().toISOString()
        };
        
        localStorage.setItem('psicoManager_user', JSON.stringify(psychologistUser));
        setUser(psychologistUser);
        resolve(psychologistUser);
      } else {
        reject(new Error('Credenciales inválidas'));
      }
    });
  };

  const logout = () => {
    localStorage.removeItem('psicoManager_user');
    setUser(null);
    window.location.href = '/login';
  };

  // Psychologist management functions (only for admins)
  const getPsychologists = (): Psychologist[] => {
    try {
      const data = localStorage.getItem('psicoManager_psychologists');
      if (!data) {
        // Initialize with demo psychologist if none exist
        const demoPsychologists: Psychologist[] = [{
          id: 'psy_demo_001',
          username: 'psicologo1',
          full_name: 'Dr. María González',
          email: 'maria.gonzalez@psicomanager.com',
          phone: '+51 999 888 777',
          license_number: 'PSI-2024-001',
          specialization: 'Psicología Clínica',
          status: 'active',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          created_by: 'admin_001'
        }];
        localStorage.setItem('psicoManager_psychologists', JSON.stringify(demoPsychologists));
        return demoPsychologists;
      }
      return JSON.parse(data);
    } catch {
      return [];
    }
  };

  const createPsychologist = (psychologistData: Omit<Psychologist, 'id' | 'created_at' | 'updated_at' | 'created_by'>): Promise<Psychologist> => {
    return new Promise((resolve, reject) => {
      if (!user || user.role !== 'admin') {
        reject(new Error('Solo los administradores pueden crear psicólogos'));
        return;
      }

      const psychologists = getPsychologists();
      
      // Check if username already exists
      if (psychologists.some(p => p.username === psychologistData.username)) {
        reject(new Error('El nombre de usuario ya existe'));
        return;
      }

      const now = new Date().toISOString();
      const newPsychologist: Psychologist = {
        ...psychologistData,
        id: 'psy_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36),
        created_at: now,
        updated_at: now,
        created_by: user.id
      };

      psychologists.push(newPsychologist);
      localStorage.setItem('psicoManager_psychologists', JSON.stringify(psychologists));
      resolve(newPsychologist);
    });
  };

  const updatePsychologist = (id: string, updates: Partial<Psychologist>): Promise<Psychologist> => {
    return new Promise((resolve, reject) => {
      if (!user) {
        reject(new Error('Usuario no autenticado'));
        return;
      }

      // Allow psychologists to edit their own profile or admins to edit any profile
      if (user.role !== 'admin' && user.id !== id) {
        reject(new Error('No tienes permiso para editar este perfil'));
        return;
      }

      const psychologists = getPsychologists();
      const index = psychologists.findIndex(p => p.id === id);
      
      if (index === -1) {
        reject(new Error('Psicólogo no encontrado'));
        return;
      }

      const updatedPsychologist = {
        ...psychologists[index],
        ...updates,
        updated_at: new Date().toISOString()
      };

      psychologists[index] = updatedPsychologist;
      localStorage.setItem('psicoManager_psychologists', JSON.stringify(psychologists));
      
      // Update user data in localStorage if editing own profile
      if (user.id === id) {
        const updatedUser = {
          ...user,
          full_name: updatedPsychologist.full_name,
          email: updatedPsychologist.email
        };
        localStorage.setItem('psicoManager_user', JSON.stringify(updatedUser));
        setUser(updatedUser);
      }
      
      resolve(updatedPsychologist);
    });
  };

  const deletePsychologist = (id: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (!user || user.role !== 'admin') {
        reject(new Error('Solo los administradores pueden eliminar psicólogos'));
        return;
      }

      const psychologists = getPsychologists();
      const filteredPsychologists = psychologists.filter(p => p.id !== id);
      
      localStorage.setItem('psicoManager_psychologists', JSON.stringify(filteredPsychologists));
      resolve();
    });
  };

  const resetPsychologistPassword = (id: string, newPassword: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (!user || user.role !== 'admin') {
        reject(new Error('Solo los administradores pueden resetear contraseñas'));
        return;
      }

      // In a real application, you would hash the password and store it
      // For demo purposes, we'll just resolve successfully
      console.log(`Password reset for psychologist ${id}: ${newPassword}`);
      resolve();
    });
  };

  const updateUserProfile = (updates: Partial<User>): Promise<User> => {
    return new Promise((resolve, reject) => {
      if (!user) {
        reject(new Error('Usuario no autenticado'));
        return;
      }

      const updatedUser = {
        ...user,
        ...updates
      };

      localStorage.setItem('psicoManager_user', JSON.stringify(updatedUser));
      setUser(updatedUser);
      resolve(updatedUser);
    });
  };

  const isAuthenticated = !!user;
  const isAdmin = user?.role === 'admin';
  const isPsychologist = user?.role === 'psychologist';

  return {
    user,
    isAuthenticated,
    isAdmin,
    isPsychologist,
    isLoading,
    login,
    logout,
    // Psychologist management (admin only)
    getPsychologists,
    createPsychologist,
    updatePsychologist,
    deletePsychologist,
    resetPsychologistPassword,
    updateUserProfile
  };
};

export type { User, Psychologist };