import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export interface User {
  id: string;
  email: string;
  username: string;
  full_name?: string;
  role: 'admin' | 'psychologist' | 'assistant';
  organization_name?: string;
  license_number?: string;
  phone?: string;
}

export const useSupabaseAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is logged in from localStorage
    const userData = localStorage.getItem('psicoManager_user');
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Error parsing user data:', error);
        localStorage.removeItem('psicoManager_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (username: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      // For demo purposes, we'll use the existing demo users
      // In production, this would validate against the database
      const demoUsers = [
        { username: 'admin', password: 'admin123', role: 'admin', full_name: 'Administrador Sistema' },
        { username: 'psicologo', password: 'psico123', role: 'psychologist', full_name: 'Dr. María González' },
        { username: 'demo', password: 'demo123', role: 'psychologist', full_name: 'Usuario Demo' }
      ];

      const foundUser = demoUsers.find(u => u.username === username && u.password === password);
      
      if (!foundUser) {
        return { success: false, error: 'Credenciales inválidas' };
      }

      const userData: User = {
        id: `demo-${foundUser.username}`,
        email: `${foundUser.username}@demo.com`,
        username: foundUser.username,
        full_name: foundUser.full_name,
        role: foundUser.role as 'admin' | 'psychologist' | 'assistant',
        organization_name: 'Centro Psicológico Demo'
      };

      setUser(userData);
      setIsAuthenticated(true);
      localStorage.setItem('psicoManager_user', JSON.stringify(userData));

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Error al iniciar sesión' };
    }
  };

  const register = async (userData: {
    email: string;
    username: string;
    password: string;
    full_name: string;
    organization_name?: string;
    license_number?: string;
    phone?: string;
  }): Promise<{ success: boolean; error?: string }> => {
    try {
      // Hash password (in production, use proper hashing)
      const hashedPassword = btoa(userData.password); // Simple base64 encoding for demo
      
      const { data, error } = await supabase
        .from('system_users')
        .insert([
          {
            email: userData.email,
            username: userData.username,
            password_hash: hashedPassword,
            full_name: userData.full_name,
            role: 'psychologist',
            organization_name: userData.organization_name,
            license_number: userData.license_number,
            phone: userData.phone
          }
        ])
        .select()
        .single();

      if (error) {
        return { success: false, error: error.message };
      }

      const newUser: User = {
        id: data.id,
        email: data.email,
        username: data.username,
        full_name: data.full_name,
        role: data.role,
        organization_name: data.organization_name,
        license_number: data.license_number,
        phone: data.phone
      };

      setUser(newUser);
      setIsAuthenticated(true);
      localStorage.setItem('psicoManager_user', JSON.stringify(newUser));

      return { success: true };
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Error al registrar usuario';
      return { success: false, error: errorMessage };
    }
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('psicoManager_user');
  };

  const isAdmin = user?.role === 'admin';

  return {
    user,
    isLoading,
    isAuthenticated,
    isAdmin,
    login,
    register,
    logout
  };
};