import { useState, useEffect } from 'react';

interface SystemSettings {
  systemName: string;
  centerName: string;
  psychologistName: string;
  logo: string;
  theme: string;
  description: string;
}

const defaultSettings: SystemSettings = {
  systemName: 'PsicoManager',
  centerName: '',
  psychologistName: '',
  logo: '',
  theme: 'default',
  description: 'Sistema de Gestión Psicológica'
};

export const useSettings = () => {
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);

  useEffect(() => {
    const savedSettings = localStorage.getItem('psicoManager_settings');
    if (savedSettings) {
      try {
        const parsedSettings = JSON.parse(savedSettings);
        setSettings({ ...defaultSettings, ...parsedSettings });
      } catch (error) {
        setSettings(defaultSettings);
      }
    }
  }, []);

  const updateSettings = (newSettings: Partial<SystemSettings>) => {
    const updatedSettings = { ...settings, ...newSettings };
    setSettings(updatedSettings);
    localStorage.setItem('psicoManager_settings', JSON.stringify(updatedSettings));
  };

  return {
    settings,
    updateSettings
  };
};