import { createClient } from '@supabase/supabase-js';

// For demo purposes, using placeholder values since Supabase is not configured
const supabaseUrl = 'https://demo.supabase.co';
const supabaseKey = 'demo-key';

// Create a mock supabase client for demo
export const supabase = {
  from: () => ({
    select: () => ({ eq: () => ({ order: () => ({ data: [], error: null }) }) }),
    insert: () => ({ select: () => ({ single: () => ({ data: null, error: null }) }) }),
    update: () => ({ eq: () => ({ select: () => ({ single: () => ({ data: null, error: null }) }) }) })
  })
};

// Types for our database
export interface Patient {
  id: string;
  user_id: string;
  full_name: string;
  birth_date?: string;
  birth_place?: string;
  age_years?: number;
  age_months?: number;
  education_level?: string;
  phone?: string;
  email?: string;
  address?: string;
  status: 'active' | 'inactive' | 'discharged';
  created_at: string;
  updated_at: string;
}

export interface AnamnesisData {
  [key: string]: string | number | boolean | object | undefined;
}

export interface Anamnesis {
  id: string;
  patient_id: string;
  user_id: string;
  consultation_reason: AnamnesisData;
  current_illness: AnamnesisData;
  prenatal_history: AnamnesisData;
  perinatal_history: AnamnesisData;
  postnatal_history: AnamnesisData;
  medical_history: AnamnesisData;
  neuromuscular_development: AnamnesisData;
  speech_development: AnamnesisData;
  habits_formation: AnamnesisData;
  behavior: AnamnesisData;
  play_behavior: AnamnesisData;
  educational_history: AnamnesisData;
  psychosexuality: AnamnesisData;
  parents_attitudes: AnamnesisData;
  family_history: AnamnesisData;
  interview_observations?: string;
  created_at: string;
  updated_at: string;
}

export interface TherapySession {
  id: string;
  patient_id: string;
  user_id: string;
  session_number: number;
  session_date: string;
  duration_minutes: number;
  session_type?: string;
  objectives?: string;
  activities_performed?: string;
  patient_behavior?: string;
  progress_observations?: string;
  achievements?: string;
  homework_assigned?: string;
  next_session_plan?: string;
  mood_scale?: number;
  anxiety_scale?: number;
  cooperation_scale?: number;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no_show';
  created_at: string;
  updated_at: string;
}

export interface PatientProgress {
  id: string;
  patient_id: string;
  user_id: string;
  goal_description: string;
  target_date?: string;
  status: 'pending' | 'in_progress' | 'achieved' | 'postponed';
  progress_percentage: number;
  notes?: string;
  created_at: string;
  updated_at: string;
}