// Database abstraction layer - using localStorage only

export interface Patient {
  id: string;
  user_id: string;
  full_name: string;
  birth_date?: string;
  birth_place?: string;
  age_years?: number;
  age_months?: number;
  education_level?: string;
  phone?: string;
  email?: string;
  address?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  status: 'active' | 'inactive' | 'discharged';
  created_at: string;
  updated_at: string;
}

export interface AnamnesisData {
  [key: string]: string | number | boolean | object | undefined;
}

export interface Anamnesis {
  id: string;
  patient_id: string;
  user_id: string;
  consultation_reason: AnamnesisData;
  current_illness: AnamnesisData;
  prenatal_history: AnamnesisData;
  perinatal_history: AnamnesisData;
  postnatal_history: AnamnesisData;
  medical_history: AnamnesisData;
  neuromuscular_development: AnamnesisData;
  speech_development: AnamnesisData;
  habits_formation: AnamnesisData;
  behavior: AnamnesisData;
  play_behavior: AnamnesisData;
  educational_history: AnamnesisData;
  psychosexuality: AnamnesisData;
  parents_attitudes: AnamnesisData;
  family_history: AnamnesisData;
  interview_observations?: string;
  created_at: string;
  updated_at: string;
}

export interface TherapySession {
  id: string;
  patient_id: string;
  user_id: string;
  session_number: number;
  session_date: string;
  duration_minutes: number;
  session_type?: string;
  objectives?: string;
  activities_performed?: string;
  patient_behavior?: string;
  progress_observations?: string;
  achievements?: string;
  homework_assigned?: string;
  next_session_plan?: string;
  mood_scale?: number;
  anxiety_scale?: number;
  cooperation_scale?: number;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no_show';
  created_at: string;
  updated_at: string;
}

export interface PatientProgress {
  id: string;
  patient_id: string;
  user_id: string;
  goal_description: string;
  target_date?: string;
  status: 'pending' | 'in_progress' | 'achieved' | 'postponed';
  progress_percentage: number;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Appointment {
  id: string;
  patient_id: string;
  user_id: string;
  appointment_date: string;
  appointment_time: string;
  duration: number;
  appointment_type: string;
  status: 'scheduled' | 'completed' | 'cancelled' | 'no_show';
  notes?: string;
  reminder_sent: boolean;
  created_at: string;
  updated_at: string;
}

class DatabaseService {
  private useSupabase = false; // Always false - using localStorage only
  
  private generateId() {
    return 'id_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
  }
  
  private getStorageKey(table: string, userId: string) {
    return `psicoManager_${table}_${userId}`;
  }
  
  private getFromStorage<T>(table: string, userId: string): T[] {
    try {
      const data = localStorage.getItem(this.getStorageKey(table, userId));
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }
  
  private saveToStorage<T>(table: string, userId: string, data: T[]) {
    localStorage.setItem(this.getStorageKey(table, userId), JSON.stringify(data));
  }

  // Patients
  async getPatients(userId: string): Promise<Patient[]> {
    // Always use localStorage since Supabase is disabled
    console.log('Getting patients from localStorage for userId:', userId);
    const patients = this.getFromStorage<Patient>('patients', userId);
    console.log('Found patients:', patients);
    return patients;
  }
  
  async createPatient(userId: string, patientData: Omit<Patient, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<Patient> {
    const now = new Date().toISOString();
    const newPatient: Patient = {
      ...patientData,
      id: this.generateId(),
      user_id: userId,
      created_at: now,
      updated_at: now
    };
    
    // Always use localStorage since Supabase is disabled
    const patients = this.getFromStorage<Patient>('patients', userId);
    patients.unshift(newPatient);
    this.saveToStorage('patients', userId, patients);
    return newPatient;
  }
  
  async updatePatient(userId: string, patientId: string, updates: Partial<Patient>): Promise<Patient> {
    const now = new Date().toISOString();
    const updateData = { ...updates, updated_at: now };
    
    // Always use localStorage since Supabase is disabled
    const patients = this.getFromStorage<Patient>('patients', userId);
    const index = patients.findIndex(p => p.id === patientId);
    if (index !== -1) {
      patients[index] = { ...patients[index], ...updateData };
      this.saveToStorage('patients', userId, patients);
      return patients[index];
    }
    throw new Error('Patient not found');
  }

  // Anamnesis
  async getAnamnesis(userId: string, patientId: string): Promise<Anamnesis | null> {
    // Always use localStorage since Supabase is disabled
    const anamnesisRecords = this.getFromStorage<Anamnesis>('anamnesis', userId);
    return anamnesisRecords.find(a => a.patient_id === patientId) || null;
  }
  
  async saveAnamnesis(userId: string, anamnesisData: Omit<Anamnesis, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<Anamnesis> {
    const now = new Date().toISOString();
    
    // Check if anamnesis already exists
    const existing = await this.getAnamnesis(userId, anamnesisData.patient_id);
    
    if (existing) {
      // Update existing
      const updateData = {
        ...anamnesisData,
        updated_at: now
      };
      
      // Always use localStorage since Supabase is disabled
      const anamnesisRecords = this.getFromStorage<Anamnesis>('anamnesis', userId);
      const index = anamnesisRecords.findIndex(a => a.id === existing.id);
      if (index !== -1) {
        anamnesisRecords[index] = { ...existing, ...updateData };
        this.saveToStorage('anamnesis', userId, anamnesisRecords);
        return anamnesisRecords[index];
      }
    } else {
      // Create new
      const newAnamnesis: Anamnesis = {
        ...anamnesisData,
        id: this.generateId(),
        user_id: userId,
        created_at: now,
        updated_at: now
      };
      
      // Always use localStorage since Supabase is disabled
      const anamnesisRecords = this.getFromStorage<Anamnesis>('anamnesis', userId);
      anamnesisRecords.push(newAnamnesis);
      this.saveToStorage('anamnesis', userId, anamnesisRecords);
      return newAnamnesis;
    }
    
    throw new Error('Failed to save anamnesis');
  }

  // Therapy Sessions
  async getSessions(userId: string, patientId?: string): Promise<TherapySession[]> {
    // Always use localStorage since Supabase is disabled
    const sessions = this.getFromStorage<TherapySession>('sessions', userId);
    return patientId ? sessions.filter(s => s.patient_id === patientId) : sessions;
  }
  
  async createSession(userId: string, sessionData: Omit<TherapySession, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<TherapySession> {
    const now = new Date().toISOString();
    const newSession: TherapySession = {
      ...sessionData,
      id: this.generateId(),
      user_id: userId,
      created_at: now,
      updated_at: now
    };
    
    // Always use localStorage since Supabase is disabled
    const sessions = this.getFromStorage<TherapySession>('sessions', userId);
    sessions.unshift(newSession);
    this.saveToStorage('sessions', userId, sessions);
    return newSession;
  }

  // Patient Progress
  async getPatientProgress(userId: string, patientId: string): Promise<PatientProgress[]> {
    // Always use localStorage since Supabase is disabled
    const progress = this.getFromStorage<PatientProgress>('progress', userId);
    return progress.filter(p => p.patient_id === patientId);
  }
  
  async createProgress(userId: string, progressData: Omit<PatientProgress, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<PatientProgress> {
    const now = new Date().toISOString();
    const newProgress: PatientProgress = {
      ...progressData,
      id: this.generateId(),
      user_id: userId,
      created_at: now,
      updated_at: now
    };
    
    // Always use localStorage since Supabase is disabled
    const progress = this.getFromStorage<PatientProgress>('progress', userId);
    progress.unshift(newProgress);
    this.saveToStorage('progress', userId, progress);
    return newProgress;
  }

  // Appointments
  async getAppointments(userId: string, date?: string): Promise<Appointment[]> {
    // Always use localStorage since Supabase is disabled
    const appointments = this.getFromStorage<Appointment>('appointments', userId);
    return date ? appointments.filter(apt => apt.appointment_date === date) : appointments;
  }

  async createAppointment(userId: string, appointmentData: Omit<Appointment, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<Appointment> {
    const now = new Date().toISOString();
    const newAppointment: Appointment = {
      ...appointmentData,
      id: this.generateId(),
      user_id: userId,
      created_at: now,
      updated_at: now
    };
    
    // Always use localStorage since Supabase is disabled
    const appointments = this.getFromStorage<Appointment>('appointments', userId);
    appointments.push(newAppointment);
    this.saveToStorage('appointments', userId, appointments);
    return newAppointment;
  }

  async updateAppointment(userId: string, appointmentId: string, updates: Partial<Appointment>): Promise<Appointment> {
    const now = new Date().toISOString();
    const updateData = { ...updates, updated_at: now };
    
    // Always use localStorage since Supabase is disabled
    const appointments = this.getFromStorage<Appointment>('appointments', userId);
    const index = appointments.findIndex(apt => apt.id === appointmentId);
    if (index !== -1) {
      appointments[index] = { ...appointments[index], ...updateData };
      this.saveToStorage('appointments', userId, appointments);
      return appointments[index];
    }
    throw new Error('Appointment not found');
  }

  async deleteAppointment(userId: string, appointmentId: string): Promise<void> {
    // Always use localStorage since Supabase is disabled
    const appointments = this.getFromStorage<Appointment>('appointments', userId);
    const filteredAppointments = appointments.filter(apt => apt.id !== appointmentId);
    this.saveToStorage('appointments', userId, filteredAppointments);
  }

  // Helper method for dashboard - add patient with simplified interface
  async addPatient(userId: string, patientData: {
    full_name: string;
    age_years?: number;
    phone?: string;
    email?: string;
    status: 'active' | 'inactive';
  }): Promise<Patient> {
    return this.createPatient(userId, {
      full_name: patientData.full_name,
      age_years: patientData.age_years,
      phone: patientData.phone,
      email: patientData.email,
      status: patientData.status,
    });
  }
}

export const db = new DatabaseService();