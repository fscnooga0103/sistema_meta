import { ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { 
  Calendar,
  Users,
  FileText,
  DollarSign,
  Home,
  Menu,
  X,
  Settings,
  LogOut,
  User
} from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useSettings } from '@/hooks/useSettings';

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, isAdmin, logout } = useAuth();
  const { settings } = useSettings();

  const navigation = user?.role === 'admin' ? [
    // General Administrator only has access to User Management
    { name: 'Gestión de Usuarios', href: '/user-management', icon: Settings }
  ] : [
    // Regular psychologists have access to all other features
    { name: 'Dashboard', href: '/', icon: Home },
    { name: 'Pacientes', href: '/patients', icon: Users },
    { name: 'Agenda', href: '/calendar', icon: Calendar },
    { name: 'Sesiones', href: '/sessions', icon: FileText },
    { name: 'Finanzas', href: '/finances', icon: DollarSign }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-25" onClick={() => setSidebarOpen(false)} />
          <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-xl flex flex-col">
            <div className="flex h-16 items-center justify-between px-4">
              <div className="flex items-center space-x-3">
                {settings.logo ? (
                  <img src={settings.logo} alt="Logo" className="h-8 w-8 object-contain" />
                ) : (
                  <div className="h-8 w-8 bg-blue-600 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-white" />
                  </div>
                )}
                <Link to="/" className="hover:opacity-80 transition-opacity">
                  <h1 className="text-xl font-semibold text-gray-900">
                    {settings.systemName}
                  </h1>
                </Link>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <nav className="mt-8 px-4 flex-1">
              <ul className="space-y-2">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  return (
                    <li key={item.name}>
                      <Link
                        to={item.href}
                        onClick={() => setSidebarOpen(false)}
                        className={cn(
                          'flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                          location.pathname === item.href
                            ? 'bg-blue-100 text-blue-700'
                            : 'text-gray-700 hover:bg-gray-100'
                        )}
                      >
                        <Icon className="mr-3 h-5 w-5" />
                        {item.name}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </nav>
            
            {/* User info and logout - Mobile */}
            <div className="mt-auto p-4 border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="h-8 w-8 bg-gray-300 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-gray-600" />
                  </div>
                  <Link to="/profile" className="hover:bg-gray-50 rounded p-1 transition-colors">
                    <p className="text-sm font-medium text-gray-700 hover:text-blue-600">{user?.username}</p>
                    <p className="text-xs text-gray-500">{user?.role === 'admin' ? 'Administrador' : user?.role === 'psychologist' ? 'Psicólogo' : 'Usuario'}</p>
                  </Link>
                </div>
                <Button variant="ghost" size="sm" onClick={logout}>
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:flex lg:w-64 lg:flex-col">
        <div className="flex grow flex-col gap-y-5 overflow-y-auto bg-white border-r border-gray-200 px-6 pb-4">
          <div className="flex h-16 shrink-0 items-center space-x-3">
            {settings.logo ? (
              <img src={settings.logo} alt="Logo" className="h-10 w-10 object-contain" />
            ) : (
              <div className="h-10 w-10 bg-blue-600 rounded-full flex items-center justify-center">
                <User className="h-5 w-5 text-white" />
              </div>
            )}
            <div>
              <Link to="/" className="hover:opacity-80 transition-opacity">
                <h1 className="text-xl font-semibold text-gray-900">
                  {settings.systemName}
                </h1>
              </Link>
              {(settings.centerName || settings.psychologistName) && (
                <p className="text-xs text-gray-500">
                  {settings.centerName || settings.psychologistName}
                </p>
              )}
            </div>
          </div>
          <nav className="flex flex-1 flex-col">
            <ul className="flex flex-1 flex-col gap-y-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.name}>
                    <Link
                      to={item.href}
                      className={cn(
                        'flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                        location.pathname === item.href
                          ? 'bg-blue-100 text-blue-700'
                          : 'text-gray-700 hover:bg-gray-100'
                      )}
                    >
                      <Icon className="mr-3 h-5 w-5" />
                      {item.name}
                    </Link>
                  </li>
                );
              })}
            </ul>

            {/* User info and logout - Desktop */}
            <div className="mt-auto p-4 border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="h-8 w-8 bg-gray-300 rounded-full flex items-center justify-center">
                    <User className="h-4 w-4 text-gray-600" />
                  </div>
                  <Link to="/profile" className="hover:bg-gray-50 rounded p-1 transition-colors">
                    <p className="text-sm font-medium text-gray-700 hover:text-blue-600">{user?.username}</p>
                    <p className="text-xs text-gray-500">{user?.role === 'admin' ? 'Administrador' : user?.role === 'psychologist' ? 'Psicólogo' : 'Usuario'}</p>
                  </Link>
                </div>
                <Button variant="ghost" size="sm" onClick={logout}>
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </nav>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Mobile header */}
        <div className="sticky top-0 z-40 flex h-16 shrink-0 items-center gap-x-4 border-b border-gray-200 bg-white px-4 shadow-sm lg:hidden">
          <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center space-x-3">
            {settings.logo ? (
              <img src={settings.logo} alt="Logo" className="h-6 w-6 object-contain" />
            ) : (
              <div className="h-6 w-6 bg-blue-600 rounded-full flex items-center justify-center">
                <User className="h-3 w-3 text-white" />
              </div>
            )}
            <Link to="/" className="hover:opacity-80 transition-opacity">
              <h1 className="text-lg font-semibold text-gray-900">{settings.systemName}</h1>
            </Link>
          </div>
        </div>

        <main className="py-10">
          <div className="px-4 sm:px-6 lg:px-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}