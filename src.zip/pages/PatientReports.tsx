import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Download, FileText, Calendar, BarChart3, TrendingUp } from 'lucide-react';
import { exportSessionReportToDocx } from '@/utils/documentExports';
import { useAuth } from '@/hooks/useAuth';
import { db, Patient, TherapySession, PatientProgress } from '@/lib/database';

export default function PatientReports() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [sessions, setSessions] = useState<TherapySession[]>([]);
  const [progress, setProgress] = useState<PatientProgress[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPatientData();
  }, [id, user]);

  const loadPatientData = async () => {
    if (!id || !user?.id) return;
    
    try {
      setIsLoading(true);
      const patients = await db.getPatients(user.id);
      const foundPatient = patients.find(p => p.id === id);
      
      if (!foundPatient) {
        navigate('/patients');
        return;
      }
      
      setPatient(foundPatient);
      
      // Load sessions and progress
      const [sessionsData, progressData] = await Promise.all([
        db.getSessions(user.id, id),
        db.getPatientProgress(user.id, id)
      ]);
      
      setSessions(sessionsData);
      setProgress(progressData);
    } catch (error) {
      console.error('Error loading patient data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const generateReport = (type: 'comprehensive' | 'progress' | 'sessions') => {
    if (!patient) return;
    
    let reportContent = '';
    const today = new Date().toLocaleDateString();
    
    // Report Header
    reportContent += `REPORTE PSICOLÓGICO\n`;
    reportContent += `====================\n\n`;
    reportContent += `Paciente: ${patient.full_name}\n`;
    reportContent += `Fecha de reporte: ${today}\n`;
    reportContent += `Profesional: ${user?.full_name || 'Psicólogo'}\n\n`;
    
    switch (type) {
      case 'comprehensive':
        reportContent += `REPORTE INTEGRAL DEL PACIENTE\n`;
        reportContent += `==============================\n\n`;
        
        // Patient Information
        reportContent += `INFORMACIÓN DEL PACIENTE:\n`;
        reportContent += `- Nombre: ${patient.full_name}\n`;
        reportContent += `- Edad: ${patient.age_years || 'No especificada'} años\n`;
        if (patient.birth_date) {
          reportContent += `- Fecha de nacimiento: ${new Date(patient.birth_date).toLocaleDateString()}\n`;
        }
        reportContent += `- Estado: ${patient.status === 'active' ? 'Activo' : patient.status}\n`;
        reportContent += `- Fecha de ingreso: ${new Date(patient.created_at).toLocaleDateString()}\n\n`;
        
        // Sessions Summary
        reportContent += `RESUMEN DE SESIONES:\n`;
        reportContent += `- Total de sesiones: ${sessions.length}\n`;
        reportContent += `- Sesiones completadas: ${sessions.filter(s => s.status === 'completed').length}\n`;
        
        if (sessions.length > 0) {
          const completedSessions = sessions.filter(s => s.status === 'completed');
          const avgDuration = completedSessions.reduce((acc, s) => acc + s.duration_minutes, 0) / completedSessions.length;
          reportContent += `- Duración promedio: ${Math.round(avgDuration)} minutos\n`;
          
          // Recent session
          const recentSession = sessions[0];
          if (recentSession) {
            reportContent += `- Última sesión: ${new Date(recentSession.session_date).toLocaleDateString()}\n`;
            if (recentSession.achievements) {
              reportContent += `- Últimos logros: ${recentSession.achievements}\n`;
            }
          }
        }
        reportContent += `\n`;
        
        // Progress Summary
        reportContent += `PROGRESO GENERAL:\n`;
        if (progress.length > 0) {
          const achievedGoals = progress.filter(p => p.status === 'achieved').length;
          const inProgressGoals = progress.filter(p => p.status === 'in_progress').length;
          
          reportContent += `- Objetivos logrados: ${achievedGoals}\n`;
          reportContent += `- Objetivos en progreso: ${inProgressGoals}\n`;
          reportContent += `- Total de objetivos: ${progress.length}\n\n`;
          
          reportContent += `OBJETIVOS DETALLADOS:\n`;
          progress.forEach((goal, index) => {
            reportContent += `${index + 1}. ${goal.goal_description}\n`;
            reportContent += `   - Estado: ${goal.status}\n`;
            reportContent += `   - Progreso: ${goal.progress_percentage}%\n`;
            if (goal.notes) {
              reportContent += `   - Notas: ${goal.notes}\n`;
            }
            reportContent += `\n`;
          });
        } else {
          reportContent += `- No se han definido objetivos específicos aún.\n\n`;
        }
        break;
        
      case 'progress':
        reportContent += `REPORTE DE PROGRESO\n`;
        reportContent += `==================\n\n`;
        
        if (progress.length > 0) {
          progress.forEach((goal, index) => {
            reportContent += `OBJETIVO ${index + 1}: ${goal.goal_description}\n`;
            reportContent += `Estado: ${goal.status === 'achieved' ? 'Logrado' : goal.status === 'in_progress' ? 'En progreso' : 'Pendiente'}\n`;
            reportContent += `Progreso: ${goal.progress_percentage}%\n`;
            if (goal.target_date) {
              reportContent += `Fecha objetivo: ${new Date(goal.target_date).toLocaleDateString()}\n`;
            }
            if (goal.notes) {
              reportContent += `Observaciones: ${goal.notes}\n`;
            }
            reportContent += `Fecha de creación: ${new Date(goal.created_at).toLocaleDateString()}\n\n`;
          });
        } else {
          reportContent += `No se han definido objetivos de progreso para este paciente.\n`;
        }
        break;
        
      case 'sessions':
        reportContent += `REPORTE DE SESIONES\n`;
        reportContent += `==================\n\n`;
        
        if (sessions.length > 0) {
          sessions.forEach((session, index) => {
            reportContent += `SESIÓN ${session.session_number}\n`;
            reportContent += `Fecha: ${new Date(session.session_date).toLocaleDateString()}\n`;
            reportContent += `Duración: ${session.duration_minutes} minutos\n`;
            reportContent += `Estado: ${session.status === 'completed' ? 'Completada' : session.status}\n`;
            
            if (session.session_type) {
              reportContent += `Tipo: ${session.session_type}\n`;
            }
            
            if (session.objectives) {
              reportContent += `Objetivos: ${session.objectives}\n`;
            }
            
            if (session.activities_performed) {
              reportContent += `Actividades realizadas: ${session.activities_performed}\n`;
            }
            
            if (session.patient_behavior) {
              reportContent += `Comportamiento del paciente: ${session.patient_behavior}\n`;
            }
            
            if (session.progress_observations) {
              reportContent += `Observaciones de progreso: ${session.progress_observations}\n`;
            }
            
            if (session.achievements) {
              reportContent += `Logros: ${session.achievements}\n`;
            }
            
            if (session.homework_assigned) {
              reportContent += `Tarea asignada: ${session.homework_assigned}\n`;
            }
            
            // Scales
            if (session.mood_scale || session.anxiety_scale || session.cooperation_scale) {
              reportContent += `Escalas de evaluación:\n`;
              if (session.mood_scale) reportContent += `  - Estado de ánimo: ${session.mood_scale}/10\n`;
              if (session.anxiety_scale) reportContent += `  - Ansiedad: ${session.anxiety_scale}/10\n`;
              if (session.cooperation_scale) reportContent += `  - Cooperación: ${session.cooperation_scale}/10\n`;
            }
            
            reportContent += `\n${'='.repeat(50)}\n\n`;
          });
        } else {
          reportContent += `No se han registrado sesiones para este paciente.\n`;
        }
        break;
    }
    
    // Download report
    const blob = new Blob([reportContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${patient.full_name.replace(/\s+/g, '_')}_${type}_${today.replace(/\//g, '-')}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const generateSessionReportDocx = async () => {
    if (!patient || !user) return;

    const completedSessions = sessions.filter(s => s.status === 'completed');
    const avgDuration = completedSessions.length > 0 
      ? Math.round(completedSessions.reduce((acc, s) => acc + s.duration_minutes, 0) / completedSessions.length)
      : 0;

    const sessionReportData = {
      patient: {
        name: patient.full_name,
        age: patient.age_years || 0
      },
      sessions: sessions.map(session => ({
        date: session.session_date,
        duration: session.duration_minutes,
        objectives: session.objectives || 'No especificados',
        activities: session.activities_performed || 'No especificadas',
        progress: session.progress_observations || 'No especificado',
        observations: session.patient_behavior || 'No especificadas',
        nextSession: session.homework_assigned || 'No especificada'
      })),
      summary: {
        totalSessions: sessions.length,
        averageDuration: avgDuration,
        overallProgress: progress.length > 0 
          ? `${Math.round(progress.reduce((acc, p) => acc + p.progress_percentage, 0) / progress.length)}% promedio`
          : 'Sin objetivos definidos'
      },
      psychologist: user.full_name || user.username || 'Psicólogo',
      generatedAt: new Date().toISOString()
    };

    try {
      await exportSessionReportToDocx(sessionReportData);
    } catch (error) {
      console.error('Error exporting session report:', error);
      alert('Error al exportar el reporte de sesiones');
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando datos del paciente...</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (!patient) {
    return (
      <Layout>
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Paciente no encontrado</h3>
          <Button onClick={() => navigate('/patients')}>
            Volver a Pacientes
          </Button>
        </div>
      </Layout>
    );
  }

  const completedSessions = sessions.filter(s => s.status === 'completed');
  const achievedGoals = progress.filter(p => p.status === 'achieved');
  const totalProgress = progress.length > 0 
    ? Math.round(progress.reduce((acc, p) => acc + p.progress_percentage, 0) / progress.length)
    : 0;

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate('/patients')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver a Pacientes
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Reportes e Informes</h1>
              <p className="text-gray-600">{patient.full_name}</p>
            </div>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Sesiones</CardTitle>
              <Calendar className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{sessions.length}</div>
              <p className="text-xs text-muted-foreground">
                {completedSessions.length} completadas
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Objetivos Logrados</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{achievedGoals.length}</div>
              <p className="text-xs text-muted-foreground">
                de {progress.length} objetivos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Progreso Promedio</CardTitle>
              <BarChart3 className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalProgress}%</div>
              <p className="text-xs text-muted-foreground">
                En todos los objetivos
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tiempo en Tratamiento</CardTitle>
              <Calendar className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Math.floor((Date.now() - new Date(patient.created_at).getTime()) / (1000 * 60 * 60 * 24))}
              </div>
              <p className="text-xs text-muted-foreground">días</p>
            </CardContent>
          </Card>
        </div>

        {/* Report Generation */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Reporte Integral
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">
                Reporte completo que incluye información del paciente, resumen de sesiones, progreso general y objetivos.
              </p>
              <Button 
                onClick={() => generateReport('comprehensive')} 
                className="w-full"
              >
                <Download className="h-4 w-4 mr-2" />
                Generar Reporte Integral
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Informe de Progreso
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">
                Informe detallado del progreso del paciente, objetivos alcanzados y metas pendientes.
              </p>
              <Button 
                onClick={() => generateReport('progress')} 
                className="w-full"
                variant="outline"
              >
                <Download className="h-4 w-4 mr-2" />
                Generar Informe de Progreso
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Calendar className="h-5 w-5 mr-2" />
                Reporte de Sesiones
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">
                Detalle completo de todas las sesiones realizadas, incluyendo objetivos, actividades y logros.
              </p>
              <div className="space-y-2">
                <Button 
                  onClick={() => generateReport('sessions')} 
                  className="w-full"
                  variant="outline"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Generar Reporte TXT
                </Button>
                <Button 
                  onClick={generateSessionReportDocx} 
                  className="w-full"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Exportar DOCX
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Progress */}
        {progress.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Progreso Reciente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {progress.slice(0, 5).map((goal) => (
                  <div key={goal.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium">{goal.goal_description}</h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge 
                          variant={
                            goal.status === 'achieved' ? 'default' : 
                            goal.status === 'in_progress' ? 'secondary' : 'outline'
                          }
                        >
                          {goal.status === 'achieved' ? 'Logrado' : 
                           goal.status === 'in_progress' ? 'En progreso' : 'Pendiente'}
                        </Badge>
                        <span className="text-sm text-gray-500">{goal.progress_percentage}%</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-500">
                        {new Date(goal.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}