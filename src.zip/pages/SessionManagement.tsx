import { useState, useEffect } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  FileText,
  Search,
  Calendar,
  User,
  Target,
  CheckCircle,
  Clock,
  Plus,
  Save,
  Edit,
  Download,
  ArrowLeft
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { db, Patient, TherapySession } from '@/lib/database';

export default function SessionManagement() {
  const { patientId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSession, setSelectedSession] = useState<string | null>(null);
  const [editingSession, setEditingSession] = useState<TherapySession | null>(null);
  const [sessions, setSessions] = useState<TherapySession[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [currentPatient, setCurrentPatient] = useState<Patient | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showNewSession, setShowNewSession] = useState(false);
  const [showEditSession, setShowEditSession] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Form data for new/edit session
  const [formData, setFormData] = useState({
    patient_id: patientId || '',
    session_date: new Date().toISOString().split('T')[0],
    duration_minutes: 60,
    session_type: 'Sesión Individual',
    objectives: '',
    activities_performed: '',
    patient_behavior: '',
    progress_observations: '',
    achievements: '',
    homework_assigned: '',
    next_session_plan: '',
    mood_scale: 5,
    anxiety_scale: 5,
    cooperation_scale: 5
  });

  useEffect(() => {
    loadData();
  }, [user, patientId]);

  const loadData = async () => {
    if (!user?.id) return;
    
    try {
      setIsLoading(true);
      const [sessionsData, patientsData] = await Promise.all([
        db.getSessions(user.id, patientId),
        db.getPatients(user.id)
      ]);
      
      setSessions(sessionsData);
      setPatients(patientsData);
      
      if (patientId) {
        const patient = patientsData.find(p => p.id === patientId);
        setCurrentPatient(patient || null);
        setFormData(prev => ({ ...prev, patient_id: patientId }));
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateSession = async () => {
    if (!user?.id || !formData.patient_id) return;
    
    try {
      setIsSaving(true);
      
      // Get next session number for this patient
      const patientSessions = sessions.filter(s => s.patient_id === formData.patient_id);
      const sessionNumber = patientSessions.length + 1;
      
      await db.createSession(user.id, {
        patient_id: formData.patient_id,
        session_number: sessionNumber,
        session_date: formData.session_date,
        duration_minutes: formData.duration_minutes,
        session_type: formData.session_type,
        objectives: formData.objectives,
        activities_performed: formData.activities_performed,
        patient_behavior: formData.patient_behavior,
        progress_observations: formData.progress_observations,
        achievements: formData.achievements,
        homework_assigned: formData.homework_assigned,
        next_session_plan: formData.next_session_plan,
        mood_scale: formData.mood_scale,
        anxiety_scale: formData.anxiety_scale,
        cooperation_scale: formData.cooperation_scale,
        status: 'completed'
      });
      
      resetForm();
      setShowNewSession(false);
      await loadData();
    } catch (error) {
      console.error('Error creating session:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleEditSession = (session: TherapySession) => {
    setEditingSession(session);
    setFormData({
      patient_id: session.patient_id,
      session_date: session.session_date,
      duration_minutes: session.duration_minutes,
      session_type: session.session_type || 'Sesión Individual',
      objectives: session.objectives || '',
      activities_performed: session.activities_performed || '',
      patient_behavior: session.patient_behavior || '',
      progress_observations: session.progress_observations || '',
      achievements: session.achievements || '',
      homework_assigned: session.homework_assigned || '',
      next_session_plan: session.next_session_plan || '',
      mood_scale: session.mood_scale || 5,
      anxiety_scale: session.anxiety_scale || 5,
      cooperation_scale: session.cooperation_scale || 5
    });
    setShowEditSession(true);
  };

  const handleUpdateSession = async () => {
    if (!user?.id || !editingSession) return;
    
    try {
      setIsSaving(true);
      // In a real app, you'd have an updateSession method
      console.log('Updating session:', editingSession.id, formData);
      resetForm();
      setShowEditSession(false);
      setEditingSession(null);
      await loadData();
    } catch (error) {
      console.error('Error updating session:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    setFormData({
      patient_id: patientId || '',
      session_date: new Date().toISOString().split('T')[0],
      duration_minutes: 60,
      session_type: 'Sesión Individual',
      objectives: '',
      activities_performed: '',
      patient_behavior: '',
      progress_observations: '',
      achievements: '',
      homework_assigned: '',
      next_session_plan: '',
      mood_scale: 5,
      anxiety_scale: 5,
      cooperation_scale: 5
    });
  };

  const generatePatientReport = () => {
    const patient = currentPatient || patients.find(p => p.id === formData.patient_id);
    if (!patient) return;

    const patientSessions = sessions.filter(s => s.patient_id === patient.id);
    
    const reportContent = `
INFORME DE PACIENTE
==================

Paciente: ${patient.full_name}
Fecha del informe: ${new Date().toLocaleDateString()}
Total de sesiones: ${patientSessions.length}

HISTORIAL DE SESIONES:
${patientSessions.map(session => `
Sesión #${session.session_number} - ${new Date(session.session_date).toLocaleDateString()}
Tipo: ${session.session_type}
Duración: ${session.duration_minutes} minutos
Objetivos: ${session.objectives || 'No especificados'}
Logros: ${session.achievements || 'No especificados'}
Estado de ánimo: ${session.mood_scale}/10
Ansiedad: ${session.anxiety_scale}/10
Cooperación: ${session.cooperation_scale}/10
---
`).join('')}

RESUMEN:
- Sesiones completadas: ${patientSessions.filter(s => s.status === 'completed').length}
- Promedio estado de ánimo: ${(patientSessions.reduce((sum, s) => sum + (s.mood_scale || 0), 0) / patientSessions.length).toFixed(1)}
- Promedio ansiedad: ${(patientSessions.reduce((sum, s) => sum + (s.anxiety_scale || 0), 0) / patientSessions.length).toFixed(1)}
- Promedio cooperación: ${(patientSessions.reduce((sum, s) => sum + (s.cooperation_scale || 0), 0) / patientSessions.length).toFixed(1)}
`;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `informe_${patient.full_name.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getPatientName = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.full_name || 'Paciente no encontrado';
  };

  const filteredSessions = sessions.filter(session =>
    getPatientName(session.patient_id).toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'no_show': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando sesiones...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            {currentPatient ? (
              <>
                <div className="flex items-center space-x-2 mb-2">
                  <Button variant="ghost" onClick={() => navigate('/patients')} size="sm">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Volver a Pacientes
                  </Button>
                </div>
                <h1 className="text-3xl font-bold text-gray-900">Sesiones de {currentPatient.full_name}</h1>
                <p className="text-gray-600">Gestiona las sesiones terapéuticas del paciente</p>
              </>
            ) : (
              <>
                <h1 className="text-3xl font-bold text-gray-900">Gestión de Sesiones</h1>
                <p className="text-gray-600">Planifica y registra sesiones terapéuticas</p>
              </>
            )}
          </div>
          
          <div className="flex space-x-2">
            {currentPatient && (
              <Button variant="outline" onClick={generatePatientReport}>
                <Download className="mr-2 h-4 w-4" />
                Generar Informe
              </Button>
            )}
            
            <Dialog open={showNewSession} onOpenChange={setShowNewSession}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Nueva Sesión
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Registrar Nueva Sesión</DialogTitle>
                </DialogHeader>
                <SessionForm 
                  formData={formData}
                  setFormData={setFormData}
                  patients={patients}
                  onSubmit={handleCreateSession}
                  onCancel={() => setShowNewSession(false)}
                  isSaving={isSaving}
                />
              </DialogContent>
            </Dialog>

            <Dialog open={showEditSession} onOpenChange={setShowEditSession}>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Editar Sesión</DialogTitle>
                </DialogHeader>
                <SessionForm 
                  formData={formData}
                  setFormData={setFormData}
                  patients={patients}
                  onSubmit={handleUpdateSession}
                  onCancel={() => {
                    setShowEditSession(false);
                    setEditingSession(null);
                  }}
                  isSaving={isSaving}
                  isEditing={true}
                />
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search */}
        {!currentPatient && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar sesiones por paciente..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Sessions List */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Registro de Sesiones</h2>
            {filteredSessions.length > 0 ? (
              filteredSessions.map((session) => (
                <Card 
                  key={session.id} 
                  className={`cursor-pointer transition-shadow ${
                    selectedSession === session.id ? 'ring-2 ring-blue-500' : 'hover:shadow-md'
                  }`}
                  onClick={() => setSelectedSession(session.id)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <User className="h-5 w-5 text-gray-500" />
                        <div>
                          <CardTitle className="text-lg">{getPatientName(session.patient_id)}</CardTitle>
                          <p className="text-sm text-gray-500">Sesión #{session.session_number} - {session.session_type}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={getStatusColor(session.status)}>
                          {session.status === 'completed' ? 'completada' : session.status}
                        </Badge>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditSession(session);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(session.session_date).toLocaleDateString('es-ES')}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{session.duration_minutes} min</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-32">
                  <div className="text-center text-gray-500">
                    <FileText className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No hay sesiones registradas</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Session Details */}
          <div className="space-y-4">
            {selectedSession ? (
              (() => {
                const session = sessions.find(s => s.id === selectedSession);
                if (!session) return null;

                return (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <FileText className="mr-2 h-5 w-5" />
                        Detalles de la Sesión
                      </CardTitle>
                      <p className="text-gray-600">
                        {getPatientName(session.patient_id)} - {new Date(session.session_date).toLocaleDateString('es-ES')}
                      </p>
                    </CardHeader>
                    <CardContent>
                      <Tabs defaultValue="objectives" className="w-full">
                        <TabsList className="grid w-full grid-cols-4">
                          <TabsTrigger value="objectives">Objetivos</TabsTrigger>
                          <TabsTrigger value="activities">Actividades</TabsTrigger>
                          <TabsTrigger value="achievements">Logros</TabsTrigger>
                          <TabsTrigger value="scales">Escalas</TabsTrigger>
                        </TabsList>

                        <TabsContent value="objectives" className="space-y-4 mt-4">
                          <div>
                            <h4 className="font-medium mb-3 flex items-center">
                              <Target className="mr-2 h-4 w-4" />
                              Objetivos de la Sesión
                            </h4>
                            <p className="text-sm bg-gray-50 p-3 rounded-lg">
                              {session.objectives || 'No se registraron objetivos'}
                            </p>
                          </div>
                        </TabsContent>

                        <TabsContent value="activities" className="space-y-4 mt-4">
                          <div>
                            <h4 className="font-medium mb-3">Actividades Realizadas</h4>
                            <p className="text-sm bg-gray-50 p-3 rounded-lg">
                              {session.activities_performed || 'No se registraron actividades'}
                            </p>
                          </div>
                          {session.homework_assigned && (
                            <div>
                              <h4 className="font-medium mb-3">Tareas Asignadas</h4>
                              <p className="text-sm bg-blue-50 p-3 rounded-lg">
                                {session.homework_assigned}
                              </p>
                            </div>
                          )}
                        </TabsContent>

                        <TabsContent value="achievements" className="space-y-4 mt-4">
                          <div>
                            <h4 className="font-medium mb-3 flex items-center">
                              <CheckCircle className="mr-2 h-4 w-4" />
                              Logros Alcanzados
                            </h4>
                            <p className="text-sm bg-green-50 p-3 rounded-lg">
                              {session.achievements || 'No se registraron logros específicos'}
                            </p>
                          </div>
                          {session.progress_observations && (
                            <div>
                              <h4 className="font-medium mb-3">Observaciones de Progreso</h4>
                              <p className="text-sm bg-gray-50 p-3 rounded-lg">
                                {session.progress_observations}
                              </p>
                            </div>
                          )}
                        </TabsContent>

                        <TabsContent value="scales" className="space-y-4 mt-4">
                          <div className="grid grid-cols-3 gap-4">
                            <div className="text-center p-3 bg-blue-50 rounded-lg">
                              <div className="text-2xl font-bold text-blue-600">{session.mood_scale}</div>
                              <div className="text-sm text-gray-600">Estado de Ánimo</div>
                            </div>
                            <div className="text-center p-3 bg-yellow-50 rounded-lg">
                              <div className="text-2xl font-bold text-yellow-600">{session.anxiety_scale}</div>
                              <div className="text-sm text-gray-600">Nivel de Ansiedad</div>
                            </div>
                            <div className="text-center p-3 bg-green-50 rounded-lg">
                              <div className="text-2xl font-bold text-green-600">{session.cooperation_scale}</div>
                              <div className="text-sm text-gray-600">Cooperación</div>
                            </div>
                          </div>
                        </TabsContent>
                      </Tabs>
                    </CardContent>
                  </Card>
                );
              })()
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-64">
                  <div className="text-center text-gray-500">
                    <FileText className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>Selecciona una sesión para ver sus detalles</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

// Session Form Component
interface SessionFormProps {
  formData: any;
  setFormData: (data: any) => void;
  patients: Patient[];
  onSubmit: () => void;
  onCancel: () => void;
  isSaving: boolean;
  isEditing?: boolean;
}

function SessionForm({ formData, setFormData, patients, onSubmit, onCancel, isSaving, isEditing = false }: SessionFormProps) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="patient">Paciente</Label>
          <Select value={formData.patient_id} onValueChange={(value) => setFormData((prev: any) => ({ ...prev, patient_id: value }))}>
            <SelectTrigger>
              <SelectValue placeholder="Seleccione un paciente" />
            </SelectTrigger>
            <SelectContent>
              {patients.map(patient => (
                <SelectItem key={patient.id} value={patient.id}>
                  {patient.full_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="session_date">Fecha</Label>
          <Input
            id="session_date"
            type="date"
            value={formData.session_date}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, session_date: e.target.value }))}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="duration">Duración (minutos)</Label>
          <Select value={formData.duration_minutes.toString()} onValueChange={(value) => setFormData((prev: any) => ({ ...prev, duration_minutes: parseInt(value) }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="30">30 minutos</SelectItem>
              <SelectItem value="45">45 minutos</SelectItem>
              <SelectItem value="60">60 minutos</SelectItem>
              <SelectItem value="90">90 minutos</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="session_type">Tipo de Sesión</Label>
          <Select value={formData.session_type} onValueChange={(value) => setFormData((prev: any) => ({ ...prev, session_type: value }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Sesión Individual">Sesión Individual</SelectItem>
              <SelectItem value="Evaluación Inicial">Evaluación Inicial</SelectItem>
              <SelectItem value="Sesión Familiar">Sesión Familiar</SelectItem>
              <SelectItem value="Seguimiento">Seguimiento</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="objectives">Objetivos de la Sesión</Label>
        <Textarea
          id="objectives"
          value={formData.objectives}
          onChange={(e) => setFormData((prev: any) => ({ ...prev, objectives: e.target.value }))}
          placeholder="Objetivos planteados para esta sesión"
        />
      </div>

      <div>
        <Label htmlFor="activities_performed">Actividades Realizadas</Label>
        <Textarea
          id="activities_performed"
          value={formData.activities_performed}
          onChange={(e) => setFormData((prev: any) => ({ ...prev, activities_performed: e.target.value }))}
          placeholder="Descripción de las actividades realizadas"
        />
      </div>

      <div>
        <Label htmlFor="achievements">Logros Alcanzados</Label>
        <Textarea
          id="achievements"
          value={formData.achievements}
          onChange={(e) => setFormData((prev: any) => ({ ...prev, achievements: e.target.value }))}
          placeholder="Logros y avances observados"
        />
      </div>

      <div>
        <Label htmlFor="homework_assigned">Tareas Asignadas</Label>
        <Textarea
          id="homework_assigned"
          value={formData.homework_assigned}
          onChange={(e) => setFormData((prev: any) => ({ ...prev, homework_assigned: e.target.value }))}
          placeholder="Tareas o ejercicios para realizar en casa"
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label htmlFor="mood_scale">Estado de Ánimo (1-10)</Label>
          <Input
            id="mood_scale"
            type="number"
            min="1"
            max="10"
            value={formData.mood_scale}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, mood_scale: parseInt(e.target.value) }))}
          />
        </div>
        <div>
          <Label htmlFor="anxiety_scale">Nivel de Ansiedad (1-10)</Label>
          <Input
            id="anxiety_scale"
            type="number"
            min="1"
            max="10"
            value={formData.anxiety_scale}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, anxiety_scale: parseInt(e.target.value) }))}
          />
        </div>
        <div>
          <Label htmlFor="cooperation_scale">Cooperación (1-10)</Label>
          <Input
            id="cooperation_scale"
            type="number"
            min="1"
            max="10"
            value={formData.cooperation_scale}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, cooperation_scale: parseInt(e.target.value) }))}
          />
        </div>
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button onClick={onSubmit} disabled={isSaving || !formData.patient_id}>
          {isSaving ? 'Guardando...' : isEditing ? 'Actualizar Sesión' : 'Registrar Sesión'}
        </Button>
      </div>
    </div>
  );
}