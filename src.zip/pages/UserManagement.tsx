import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  Users,
  UserPlus,
  Edit,
  Trash2,
  Key,
  Shield,
  Search
} from 'lucide-react';
import { useAuth, Psychologist } from '@/hooks/useAuth';

export default function UserManagement() {
  const { user, getPsychologists, createPsychologist, updatePsychologist, deletePsychologist, resetPsychologistPassword } = useAuth();
  const [psychologists, setPsychologists] = useState<Psychologist[]>([]);
  const [filteredPsychologists, setFilteredPsychologists] = useState<Psychologist[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewPsychologist, setShowNewPsychologist] = useState(false);
  const [editingPsychologist, setEditingPsychologist] = useState<Psychologist | null>(null);
  const [showEditPsychologist, setShowEditPsychologist] = useState(false);
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [resetPasswordPsychologist, setResetPasswordPsychologist] = useState<Psychologist | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const [newPsychologist, setNewPsychologist] = useState({
    username: '',
    full_name: '',
    email: '',
    phone: '',
    license_number: '',
    specialization: '',
    status: 'active' as const
  });

  const [editForm, setEditForm] = useState({
    username: '',
    full_name: '',
    email: '',
    phone: '',
    license_number: '',
    specialization: '',
    status: 'active' as const
  });

  const [passwordForm, setPasswordForm] = useState({
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    loadPsychologists();
  }, []);

  useEffect(() => {
    filterPsychologists();
  }, [psychologists, searchTerm]);

  const loadPsychologists = () => {
    setIsLoading(true);
    const data = getPsychologists();
    setPsychologists(data);
    setIsLoading(false);
  };

  const filterPsychologists = () => {
    let filtered = psychologists;
    
    if (searchTerm) {
      filtered = filtered.filter(psychologist =>
        psychologist.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        psychologist.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        psychologist.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredPsychologists(filtered);
  };

  const handleAddPsychologist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || user.role !== 'admin') return;

    try {
      setIsSaving(true);
      await createPsychologist(newPsychologist);
      
      // Reset form
      setNewPsychologist({
        username: '',
        full_name: '',
        email: '',
        phone: '',
        license_number: '',
        specialization: '',
        status: 'active'
      });
      
      setShowNewPsychologist(false);
      loadPsychologists();
    } catch (error) {
      console.error('Error creating psychologist:', error);
      alert(error instanceof Error ? error.message : 'Error al crear psicólogo');
    } finally {
      setIsSaving(false);
    }
  };

  const handleEditPsychologist = (psychologist: Psychologist) => {
    setEditingPsychologist(psychologist);
    setEditForm({
      username: psychologist.username,
      full_name: psychologist.full_name,
      email: psychologist.email,
      phone: psychologist.phone || '',
      license_number: psychologist.license_number || '',
      specialization: psychologist.specialization || '',
      status: psychologist.status
    });
    setShowEditPsychologist(true);
  };

  const handleUpdatePsychologist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPsychologist) return;

    try {
      setIsSaving(true);
      await updatePsychologist(editingPsychologist.id, editForm);
      
      setShowEditPsychologist(false);
      setEditingPsychologist(null);
      loadPsychologists();
    } catch (error) {
      console.error('Error updating psychologist:', error);
      alert(error instanceof Error ? error.message : 'Error al actualizar psicólogo');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeletePsychologist = async (psychologist: Psychologist) => {
    if (!confirm(`¿Está seguro de eliminar al psicólogo ${psychologist.full_name}?`)) return;

    try {
      await deletePsychologist(psychologist.id);
      loadPsychologists();
    } catch (error) {
      console.error('Error deleting psychologist:', error);
      alert(error instanceof Error ? error.message : 'Error al eliminar psicólogo');
    }
  };

  const handleResetPassword = (psychologist: Psychologist) => {
    setResetPasswordPsychologist(psychologist);
    setPasswordForm({ newPassword: '', confirmPassword: '' });
    setShowResetPassword(true);
  };

  const handleSubmitPasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPasswordPsychologist) return;
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      alert('Las contraseñas no coinciden');
      return;
    }

    if (passwordForm.newPassword.length < 6) {
      alert('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    try {
      setIsSaving(true);
      await resetPsychologistPassword(resetPasswordPsychologist.id, passwordForm.newPassword);
      
      setShowResetPassword(false);
      setResetPasswordPsychologist(null);
      setPasswordForm({ newPassword: '', confirmPassword: '' });
      
      alert(`Contraseña actualizada para ${resetPasswordPsychologist.full_name}`);
    } catch (error) {
      console.error('Error resetting password:', error);
      alert(error instanceof Error ? error.message : 'Error al resetear contraseña');
    } finally {
      setIsSaving(false);
    }
  };

  if (!user || user.role !== 'admin') {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Shield className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Acceso Restringido</h3>
            <p className="text-gray-600">Solo los administradores pueden acceder a esta sección.</p>
          </div>
        </div>
      </Layout>
    );
  }

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando usuarios...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestión de Usuarios</h1>
            <p className="text-gray-600">Administra los psicólogos del sistema</p>
          </div>
          
          <Dialog open={showNewPsychologist} onOpenChange={setShowNewPsychologist}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="mr-2 h-4 w-4" />
                Nuevo Psicólogo
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Psicólogo</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAddPsychologist} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="username">Usuario</Label>
                    <Input
                      id="username"
                      value={newPsychologist.username}
                      onChange={(e) => setNewPsychologist(prev => ({ ...prev, username: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="full_name">Nombre Completo</Label>
                    <Input
                      id="full_name"
                      value={newPsychologist.full_name}
                      onChange={(e) => setNewPsychologist(prev => ({ ...prev, full_name: e.target.value }))}
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newPsychologist.email}
                      onChange={(e) => setNewPsychologist(prev => ({ ...prev, email: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      value={newPsychologist.phone}
                      onChange={(e) => setNewPsychologist(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="license_number">Número de Licencia</Label>
                    <Input
                      id="license_number"
                      value={newPsychologist.license_number}
                      onChange={(e) => setNewPsychologist(prev => ({ ...prev, license_number: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="specialization">Especialización</Label>
                    <Input
                      id="specialization"
                      value={newPsychologist.specialization}
                      onChange={(e) => setNewPsychologist(prev => ({ ...prev, specialization: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowNewPsychologist(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={isSaving}>
                    {isSaving ? 'Guardando...' : 'Crear Psicólogo'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Psicólogos</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{psychologists.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Activos</CardTitle>
              <Users className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{psychologists.filter(p => p.status === 'active').length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Inactivos</CardTitle>
              <Users className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{psychologists.filter(p => p.status === 'inactive').length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar psicólogos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Psychologists List */}
        <Card>
          <CardHeader>
            <CardTitle>Psicólogos Registrados</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredPsychologists.length > 0 ? (
              <div className="space-y-4">
                {filteredPsychologists.map((psychologist) => (
                  <div key={psychologist.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-medium">{psychologist.full_name}</h4>
                            <Badge variant={psychologist.status === 'active' ? 'default' : 'secondary'}>
                              {psychologist.status === 'active' ? 'Activo' : 'Inactivo'}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">@{psychologist.username}</p>
                          <p className="text-sm text-gray-600">{psychologist.email}</p>
                          {psychologist.specialization && (
                            <p className="text-sm text-blue-600">{psychologist.specialization}</p>
                          )}
                        </div>
                        <div className="text-right text-sm text-gray-500">
                          <p>Creado: {new Date(psychologist.created_at).toLocaleDateString()}</p>
                          {psychologist.license_number && (
                            <p>Licencia: {psychologist.license_number}</p>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditPsychologist(psychologist)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleResetPassword(psychologist)}
                      >
                        <Key className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeletePsychologist(psychologist)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Users className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <p>No hay psicólogos registrados</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={showEditPsychologist} onOpenChange={setShowEditPsychologist}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Editar Psicólogo</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpdatePsychologist} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_username">Usuario</Label>
                  <Input
                    id="edit_username"
                    value={editForm.username}
                    onChange={(e) => setEditForm(prev => ({ ...prev, username: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit_full_name">Nombre Completo</Label>
                  <Input
                    id="edit_full_name"
                    value={editForm.full_name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, full_name: e.target.value }))}
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_email">Email</Label>
                  <Input
                    id="edit_email"
                    type="email"
                    value={editForm.email}
                    onChange={(e) => setEditForm(prev => ({ ...prev, email: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit_phone">Teléfono</Label>
                  <Input
                    id="edit_phone"
                    value={editForm.phone}
                    onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setShowEditPsychologist(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={isSaving}>
                  {isSaving ? 'Guardando...' : 'Actualizar'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>

        {/* Reset Password Dialog */}
        <Dialog open={showResetPassword} onOpenChange={setShowResetPassword}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Resetear Contraseña</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmitPasswordReset} className="space-y-4">
              <p className="text-sm text-gray-600">
                Resetear contraseña para: <strong>{resetPasswordPsychologist?.full_name}</strong>
              </p>
              
              <div>
                <Label htmlFor="new_password">Nueva Contraseña</Label>
                <Input
                  id="new_password"
                  type="password"
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm(prev => ({ ...prev, newPassword: e.target.value }))}
                  required
                  minLength={6}
                />
              </div>
              
              <div>
                <Label htmlFor="confirm_password">Confirmar Contraseña</Label>
                <Input
                  id="confirm_password"
                  type="password"
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
                  required
                  minLength={6}
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setShowResetPassword(false)}>
                  Cancelar
                </Button>
                <Button type="submit" disabled={isSaving}>
                  {isSaving ? 'Reseteando...' : 'Resetear Contraseña'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}