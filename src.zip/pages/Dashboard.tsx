import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Calendar, DollarSign, FileText, User, ArrowRight, UserPlus, Plus } from 'lucide-react';
import { useSettings } from '@/hooks/useSettings';
import { useAuth } from '@/hooks/useAuth';
import { db } from '@/lib/database';

export default function Dashboard() {
  const { settings } = useSettings();
  const { user } = useAuth();
  const [showNewPatientDialog, setShowNewPatientDialog] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newPatient, setNewPatient] = useState({
    full_name: '',
    age_years: '',
    phone: '',
    email: '',
    status: 'active' as const
  });

  const [dashboardStats, setDashboardStats] = useState({
    totalPatients: 0,
    todayAppointments: 0,
    monthlyIncome: 0,
    completedSessions: 0
  });

  const [recentAppointments, setRecentAppointments] = useState<Array<{
    id: string;
    patient: string;
    time: string;
    type: string;
    status: string;
  }>>([]);
  
  useEffect(() => {
    loadDashboardData();
    // Update dashboard every 30 seconds
    const interval = setInterval(loadDashboardData, 30000);
    
    // Listen for appointment changes
    const handleAppointmentChange = () => {
      console.log('Dashboard: Appointment change detected, refreshing data...');
      loadDashboardData();
    };
    
    const handleForceRefresh = () => {
      console.log('Dashboard: Force refresh triggered');
      loadDashboardData();
    };
    
    window.addEventListener('appointmentCreated', handleAppointmentChange);
    window.addEventListener('appointmentUpdated', handleAppointmentChange);
    window.addEventListener('forceRefresh', handleForceRefresh);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('appointmentCreated', handleAppointmentChange);
      window.removeEventListener('appointmentUpdated', handleAppointmentChange);
      window.removeEventListener('forceRefresh', handleForceRefresh);
    };
  }, [user]);

  const loadDashboardData = async () => {
    if (!user?.id) return;

    try {
      // Load patients
      const patients = await db.getPatients(user.id);
      const activePatients = patients.filter(p => p.status === 'active');

      // Load financial data from localStorage
      const paymentsData = localStorage.getItem(`psicoManager_payments_${user.id}`);
      const payments = paymentsData ? JSON.parse(paymentsData) : [];
      
      // Calculate monthly income
      const now = new Date();
      const monthlyPayments = payments.filter((p: { payment_date: string; amount: number }) => {
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getMonth() === now.getMonth() && 
               paymentDate.getFullYear() === now.getFullYear();
      });
      const monthlyIncome = monthlyPayments.reduce((sum: number, p: { amount: number }) => sum + p.amount, 0);

      // Load sessions data
      const allSessions = [];
      for (const patient of patients) {
        try {
          const sessions = await db.getSessions(user.id, patient.id);
          allSessions.push(...sessions);
        } catch (error) {
          // Continue if patient has no sessions
        }
      }
      const completedSessions = allSessions.filter(s => s.status === 'completed');

      // Load real appointments data with improved date handling
      const allAppointments = await db.getAppointments(user.id);
      const today = new Date();
      const todayString = today.toISOString().split('T')[0];
      
      // Filter today's appointments with better date comparison
      const todayAppointments = allAppointments.filter(apt => {
        if (!apt.appointment_date) return false;
        const aptDate = apt.appointment_date.split('T')[0]; // Handle both date strings and ISO dates
        return aptDate === todayString;
      });

      // Load today's appointments with patient names and sort by time
      const todayAppointmentsWithNames = todayAppointments
        .map(apt => {
          const patient = patients.find(p => p.id === apt.patient_id);
          return {
            id: apt.id,
            patient: patient?.full_name || 'Paciente no encontrado',
            time: apt.appointment_time,
            type: apt.appointment_type,
            status: apt.status
          };
        })
        .sort((a, b) => a.time.localeCompare(b.time)); // Sort by time

      setDashboardStats({
        totalPatients: activePatients.length,
        todayAppointments: todayAppointments.length,
        monthlyIncome,
        completedSessions: completedSessions.length
      });

      setRecentAppointments(todayAppointmentsWithNames.slice(0, 4));
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    }
  };

  const stats = [
    { 
      name: 'Total Pacientes', 
      value: dashboardStats.totalPatients.toString(), 
      icon: Users, 
      color: 'text-blue-600', 
      href: '/patients',
      description: 'Ver todos los pacientes'
    },
    { 
      name: 'Citas Hoy', 
      value: dashboardStats.todayAppointments.toString(), 
      icon: Calendar, 
      color: 'text-green-600', 
      href: '/calendar',
      description: 'Ver agenda completa'
    },
    { 
      name: 'Ingresos del Mes', 
      value: `$${dashboardStats.monthlyIncome.toFixed(0)}`, 
      icon: DollarSign, 
      color: 'text-yellow-600', 
      href: '/finances',
      description: 'Ver finanzas detalladas'
    },
    { 
      name: 'Sesiones Completadas', 
      value: dashboardStats.completedSessions.toString(), 
      icon: FileText, 
      color: 'text-purple-600', 
      href: '/sessions',
      description: 'Ver todas las sesiones'
    },
  ];

  const handleCreatePatient = async () => {
    if (!user?.id || !newPatient.full_name.trim()) return;
    
    try {
      setIsCreating(true);
      
      await db.addPatient(user.id, {
        full_name: newPatient.full_name.trim(),
        age_years: newPatient.age_years ? parseInt(newPatient.age_years) : undefined,
        phone: newPatient.phone.trim() || undefined,
        email: newPatient.email.trim() || undefined,
        status: newPatient.status
      });
      
      // Reset form
      setNewPatient({
        full_name: '',
        age_years: '',
        phone: '',
        email: '',
        status: 'active'
      });
      
      setShowNewPatientDialog(false);
      
      // Refresh dashboard data immediately
      await loadDashboardData();
    } catch (error) {
      console.error('Error creating patient:', error);
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex items-center space-x-4">
          {settings.logo ? (
            <img src={settings.logo} alt="Logo" className="h-16 w-16 object-contain" />
          ) : (
            <div className="h-16 w-16 bg-blue-600 rounded-full flex items-center justify-center">
              <User className="h-8 w-8 text-white" />
            </div>
          )}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {settings.centerName || settings.systemName}
            </h1>
            <p className="text-gray-600">
              {settings.psychologistName ? `Dr. ${settings.psychologistName}` : settings.description}
            </p>
            <p className="text-sm text-gray-500">Bienvenido, {user?.username}</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Link key={stat.name} to={stat.href}>
                <Card className="hover:shadow-lg transition-all duration-200 cursor-pointer hover:scale-105 group">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-600 group-hover:text-gray-900">
                      {stat.name}
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Icon className={`h-5 w-5 ${stat.color} group-hover:scale-110 transition-transform`} />
                      <ArrowRight className="h-3 w-3 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold group-hover:text-blue-600 transition-colors">{stat.value}</div>
                    <p className="text-xs text-gray-500 mt-1 group-hover:text-gray-700">
                      {stat.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        {/* Recent Appointments and Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Citas de Hoy</CardTitle>
              <Link to="/calendar" className="text-sm text-blue-600 hover:text-blue-800 flex items-center">
                Ver todas
                <ArrowRight className="h-3 w-3 ml-1" />
              </Link>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAppointments.length > 0 ? (
                  recentAppointments.map((appointment) => (
                    <Link key={appointment.id} to="/calendar">
                      <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer group">
                        <div>
                          <p className="font-medium group-hover:text-blue-600">{appointment.patient}</p>
                          <p className="text-sm text-gray-500">{appointment.type}</p>
                        </div>
                        <div className="text-right flex items-center space-x-2">
                          <div className="text-right">
                            <p className="font-medium">{appointment.time}</p>
                            <p className="text-xs text-gray-500 capitalize">{appointment.status}</p>
                          </div>
                          <ArrowRight className="h-3 w-3 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                    <p>No hay citas programadas para hoy</p>
                    <Link to="/calendar">
                      <Button variant="outline" className="mt-4">
                        <Plus className="h-4 w-4 mr-2" />
                        Programar Primera Cita
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Acciones Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div 
                onClick={() => setShowNewPatientDialog(true)}
                className="flex items-center justify-between p-4 border-2 border-blue-200 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer group"
              >
                <div className="flex items-center space-x-3">
                  <UserPlus className="h-5 w-5 text-blue-600" />
                  <span className="font-semibold text-blue-700 group-hover:text-blue-800">Nuevo Paciente</span>
                </div>
                <ArrowRight className="h-4 w-4 text-blue-600 group-hover:text-blue-700" />
              </div>

              <Link to="/patients">
                <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-blue-50 transition-colors cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <Users className="h-5 w-5 text-blue-600" />
                    <span className="font-medium group-hover:text-blue-700">Gestionar Pacientes</span>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-blue-600" />
                </div>
              </Link>

              <Link to="/calendar">
                <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-green-50 transition-colors cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-green-600" />
                    <span className="font-medium group-hover:text-green-700">Programar Cita</span>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-green-600" />
                </div>
              </Link>

              <Link to="/sessions">
                <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-purple-50 transition-colors cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-5 w-5 text-purple-600" />
                    <span className="font-medium group-hover:text-purple-700">Nueva Sesión</span>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-purple-600" />
                </div>
              </Link>

              <Link to="/finances">
                <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-yellow-50 transition-colors cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <DollarSign className="h-5 w-5 text-yellow-600" />
                    <span className="font-medium group-hover:text-yellow-700">Revisar Ingresos</span>
                  </div>
                  <ArrowRight className="h-4 w-4 text-gray-400 group-hover:text-yellow-600" />
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* New Patient Dialog */}
        <Dialog open={showNewPatientDialog} onOpenChange={setShowNewPatientDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <UserPlus className="h-5 w-5 mr-2" />
                Agregar Nuevo Paciente
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="patientName">Nombre Completo *</Label>
                <Input
                  id="patientName"
                  placeholder="Apellidos y nombres del paciente"
                  value={newPatient.full_name}
                  onChange={(e) => setNewPatient(prev => ({ ...prev, full_name: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="patientAge">Edad (años)</Label>
                <Input
                  id="patientAge"
                  type="number"
                  placeholder="Edad en años"
                  value={newPatient.age_years}
                  onChange={(e) => setNewPatient(prev => ({ ...prev, age_years: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="patientPhone">Teléfono</Label>
                <Input
                  id="patientPhone"
                  placeholder="Número de teléfono"
                  value={newPatient.phone}
                  onChange={(e) => setNewPatient(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="patientEmail">Email</Label>
                <Input
                  id="patientEmail"
                  type="email"
                  placeholder="Correo electrónico"
                  value={newPatient.email}
                  onChange={(e) => setNewPatient(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="patientStatus">Estado</Label>
                <Select value={newPatient.status} onValueChange={(value: 'active' | 'inactive') => setNewPatient(prev => ({ ...prev, status: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Activo</SelectItem>
                    <SelectItem value="inactive">Inactivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setShowNewPatientDialog(false)}
                  disabled={isCreating}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleCreatePatient}
                  disabled={isCreating || !newPatient.full_name.trim()}
                >
                  {isCreating ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <UserPlus className="h-4 w-4 mr-2" />
                  )}
                  Crear Paciente
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}