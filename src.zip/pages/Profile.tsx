import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  User,
  Mail,
  Phone,
  Shield,
  Calendar,
  Save,
  Key
} from 'lucide-react';
import { useAuth, Psychologist } from '@/hooks/useAuth';

export default function Profile() {
  const { user, getPsychologists, updatePsychologist, updateUserProfile } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [currentPsychologist, setCurrentPsychologist] = useState<Psychologist | null>(null);

  const [profileForm, setProfileForm] = useState({
    full_name: '',
    email: '',
    phone: '',
    license_number: '',
    specialization: ''
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    if (user?.role === 'psychologist') {
      loadPsychologistData();
    } else if (user?.role === 'admin') {
      // For admin, use user data directly
      setProfileForm({
        full_name: user.full_name || '',
        email: user.email || '',
        phone: '',
        license_number: '',
        specialization: 'Administración del Sistema'
      });
    }
  }, [user]);

  const loadPsychologistData = () => {
    if (!user?.id) return;
    
    const psychologists = getPsychologists();
    const psychologist = psychologists.find(p => p.id === user.id);
    
    if (psychologist) {
      setCurrentPsychologist(psychologist);
      setProfileForm({
        full_name: psychologist.full_name,
        email: psychologist.email,
        phone: psychologist.phone || '',
        license_number: psychologist.license_number || '',
        specialization: psychologist.specialization || ''
      });
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;

    try {
      setIsSaving(true);
      
      if (user.role === 'psychologist' && currentPsychologist) {
        await updatePsychologist(currentPsychologist.id, profileForm);
        // Update local state
        loadPsychologistData();
      } else if (user.role === 'admin') {
        await updateUserProfile({
          full_name: profileForm.full_name,
          email: profileForm.email
        });
      }
      
      alert('Perfil actualizado exitosamente');
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Error al actualizar el perfil');
    } finally {
      setIsSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      alert('Las contraseñas no coinciden');
      return;
    }

    if (passwordForm.newPassword.length < 6) {
      alert('La contraseña debe tener al menos 6 caracteres');
      return;
    }

    try {
      setIsSaving(true);
      // In a real application, you would verify the current password and update it
      console.log('Password change requested for user:', user?.id);
      
      // Reset form
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      
      alert('Contraseña actualizada exitosamente');
    } catch (error) {
      console.error('Error changing password:', error);
      alert('Error al cambiar la contraseña');
    } finally {
      setIsSaving(false);
    }
  };

  if (!user) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <User className="mx-auto h-12 w-12 text-gray-300 mb-4" />
            <p className="text-gray-600">No se pudo cargar la información del perfil</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mi Perfil</h1>
          <p className="text-gray-600">Gestiona tu información personal y configuración de cuenta</p>
        </div>

        {/* Profile Overview Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <User className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-xl">{user.full_name || user.username}</CardTitle>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                    {user.role === 'admin' ? 'Administrador General' : 'Psicólogo'}
                  </Badge>
                  {currentPsychologist?.status && (
                    <Badge variant={currentPsychologist.status === 'active' ? 'default' : 'secondary'}>
                      {currentPsychologist.status === 'active' ? 'Activo' : 'Inactivo'}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-gray-500" />
                <span>{user.email}</span>
              </div>
              {currentPsychologist?.phone && (
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <span>{currentPsychologist.phone}</span>
                </div>
              )}
              <div className="flex items-center space-x-2">
                <Shield className="h-4 w-4 text-gray-500" />
                <span>@{user.username}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <span>Última sesión: {new Date(user.loginTime).toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Management Tabs */}
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="profile">Información Personal</TabsTrigger>
            <TabsTrigger value="security">Seguridad</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Información Personal</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="full_name">Nombre Completo</Label>
                      <Input
                        id="full_name"
                        value={profileForm.full_name}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, full_name: e.target.value }))}
                        disabled={user.role === 'admin'}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profileForm.email}
                        onChange={(e) => setProfileForm(prev => ({ ...prev, email: e.target.value }))}
                        disabled={user.role === 'admin'}
                      />
                    </div>
                  </div>

                  {user.role === 'psychologist' && (
                    <>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Teléfono</Label>
                          <Input
                            id="phone"
                            value={profileForm.phone}
                            onChange={(e) => setProfileForm(prev => ({ ...prev, phone: e.target.value }))}
                          />
                        </div>
                        <div>
                          <Label htmlFor="license_number">Número de Licencia</Label>
                          <Input
                            id="license_number"
                            value={profileForm.license_number}
                            onChange={(e) => setProfileForm(prev => ({ ...prev, license_number: e.target.value }))}
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="specialization">Especialización</Label>
                        <Input
                          id="specialization"
                          value={profileForm.specialization}
                          onChange={(e) => setProfileForm(prev => ({ ...prev, specialization: e.target.value }))}
                        />
                      </div>
                    </>
                  )}

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isSaving}>
                      <Save className="h-4 w-4 mr-2" />
                      {isSaving ? 'Guardando...' : 'Guardar Cambios'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Cambiar Contraseña</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div>
                    <Label htmlFor="current_password">Contraseña Actual</Label>
                    <Input
                      id="current_password"
                      type="password"
                      value={passwordForm.currentPassword}
                      onChange={(e) => setPasswordForm(prev => ({ ...prev, currentPassword: e.target.value }))}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="new_password">Nueva Contraseña</Label>
                    <Input
                      id="new_password"
                      type="password"
                      value={passwordForm.newPassword}
                      onChange={(e) => setPasswordForm(prev => ({ ...prev, newPassword: e.target.value }))}
                      required
                      minLength={6}
                    />
                  </div>

                  <div>
                    <Label htmlFor="confirm_password">Confirmar Nueva Contraseña</Label>
                    <Input
                      id="confirm_password"
                      type="password"
                      value={passwordForm.confirmPassword}
                      onChange={(e) => setPasswordForm(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      required
                      minLength={6}
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={isSaving}>
                      <Key className="h-4 w-4 mr-2" />
                      {isSaving ? 'Cambiando...' : 'Cambiar Contraseña'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}