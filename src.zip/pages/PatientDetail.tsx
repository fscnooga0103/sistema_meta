import { useState } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  User, 
  Calendar, 
  FileText, 
  Target,
  Edit,
  Save,
  X
} from 'lucide-react';

export default function PatientDetail() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('historia');
  const [isEditing, setIsEditing] = useState(false);
  const [notes, setNotes] = useState('');

  // Mock patient data
  const patient = {
    id: parseInt(id || '1'),
    name: 'Ana García',
    age: 28,
    phone: '+1 234 567 8900',
    email: 'ana.garcia@email.com',
    diagnosis: 'Trastorno de Ansiedad Generalizada',
    startDate: '2023-10-15',
    sessions: 8,
    progress: 75,
    clinicalHistory: 'Paciente de 28 años que presenta síntomas de ansiedad generalizada desde hace 6 meses. Refiere preocupación excesiva, dificultades para conciliar el sueño y tensión muscular.',
    evaluation: 'GAD-7: 14 puntos (ansiedad moderada)\nBDI-II: 8 puntos (síntomas mínimos de depresión)',
    presumptiveDiagnosis: 'F41.1 Trastorno de ansiedad generalizada',
    weeklyGoals: [
      { week: 1, goal: 'Identificar triggers de ansiedad', completed: true },
      { week: 2, goal: 'Práctica de respiración diafragmática', completed: true },
      { week: 3, goal: 'Técnicas de relajación muscular', completed: true },
      { week: 4, goal: 'Reestructuración cognitiva básica', completed: false },
    ]
  };

  const achievements = [
    'Reducción del 40% en episodios de ansiedad',
    'Mejora en calidad del sueño',
    'Mayor autoconciencia emocional',
    'Implementación exitosa de técnicas de relajación'
  ];

  return (
    <Layout>
      <div className="flex gap-8">
        {/* Main Content */}
        <div className="flex-1 space-y-8">
          {/* Patient Header */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="h-16 w-16 rounded-full bg-gray-200 flex items-center justify-center">
                    <User className="h-8 w-8 text-gray-500" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold">{patient.name}</h1>
                    <p className="text-gray-600">{patient.age} años • {patient.phone}</p>
                    <p className="text-gray-600">{patient.email}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">Progreso General</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <Progress value={patient.progress} className="w-24" />
                    <span className="text-sm font-medium">{patient.progress}%</span>
                  </div>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="historia">Historia Clínica</TabsTrigger>
              <TabsTrigger value="progreso">Progreso</TabsTrigger>
              <TabsTrigger value="logros">Logros</TabsTrigger>
              <TabsTrigger value="sesiones">Sesiones</TabsTrigger>
            </TabsList>

            <TabsContent value="historia" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Historia Clínica</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 leading-relaxed">{patient.clinicalHistory}</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="progreso" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Objetivos Semanales</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {patient.weeklyGoals.map((goal) => (
                      <div key={goal.week} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Target className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium">Semana {goal.week}</p>
                            <p className="text-sm text-gray-600">{goal.goal}</p>
                          </div>
                        </div>
                        <Badge variant={goal.completed ? "default" : "secondary"}>
                          {goal.completed ? 'Completado' : 'En progreso'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="logros" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Logros Alcanzados</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                        <div className="h-2 w-2 bg-green-500 rounded-full" />
                        <p className="text-green-800">{achievement}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sesiones" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Historial de Sesiones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5].map((session) => (
                      <div key={session} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Calendar className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium">Sesión {session}</p>
                            <p className="text-sm text-gray-600">2024-01-{10 + session}</p>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">Ver Detalles</Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="w-80 space-y-6">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Acciones Rápidas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start">
                <Calendar className="mr-2 h-4 w-4" />
                Agendar Cita
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <FileText className="mr-2 h-4 w-4" />
                Nueva Sesión
              </Button>
            </CardContent>
          </Card>

          {/* Evaluation */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Evaluación</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="font-medium text-gray-700">Instrumentos Aplicados:</p>
                  <p className="text-gray-600">{patient.evaluation}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Presumptive Diagnosis */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Diagnóstico Presuntivo</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700">{patient.presumptiveDiagnosis}</p>
            </CardContent>
          </Card>

          {/* Notes */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Anotaciones</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? <X className="h-4 w-4" /> : <Edit className="h-4 w-4" />}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <div className="space-y-3">
                  <Textarea
                    placeholder="Escribir anotaciones..."
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="min-h-[100px]"
                  />
                  <Button size="sm" onClick={() => setIsEditing(false)}>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar
                  </Button>
                </div>
              ) : (
                <p className="text-sm text-gray-600">
                  {notes || 'No hay anotaciones. Haz clic en editar para agregar.'}
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}