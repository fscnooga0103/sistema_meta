import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Save, FileText, Users, User, GraduationCap, Heart, Home, Eye, Download } from 'lucide-react';
import { exportClinicalHistoryToDocx } from '@/utils/documentExports';
import { useAuth } from '@/hooks/useAuth';
import { db, Patient, Anamnesis } from '@/lib/database';

export default function ClinicalHistory() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [patient, setPatient] = useState<Patient | null>(null);
  const [anamnesis, setAnamnesis] = useState<Anamnesis | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('personal');
  
  const [formData, setFormData] = useState({
    personalData: {
      fullName: '', birthDate: '', birthPlace: '', age: '', gender: '', 
      idDocument: '', address: '', phone: '', emergencyContact: '', emergencyPhone: ''
    },
    familyStructure: {
      fatherName: '', fatherAge: '', fatherOccupation: '', fatherEducation: '',
      motherName: '', motherAge: '', motherOccupation: '', motherEducation: '',
      maritalStatus: '', siblings: '', familyDynamics: '', livingWith: ''
    },
    consultationReason: {
      mainProblem: '', whenStarted: '', whoDetected: '', evolution: '', 
      previousTreatments: '', familyConcerns: '', patientExpectations: ''
    },
    habits: {
      appetite: '', eatingSchedule: '', foodPreferences: '', bathingRoutine: '',
      teethBrushing: '', personalCare: '', sleepHours: '', bedtime: '', 
      sleepDifficulties: '', dressing: '', selfCareSkills: '', independence: ''
    },
    behavior: {
      temperament: '', socialBehavior: '', attention: '', behaviorChanges: '',
      aggressiveBehavior: '', fearAnxiety: '', hyperactivity: '', obedience: ''
    },
    educationalHistory: {
      currentGrade: '', schoolName: '', academicPerformance: '', learningDifficulties: '',
      teacherRelationship: '', peerRelationship: '', schoolBehavior: '', specialServices: ''
    },
    familyRelationships: {
      parentRelationship: '', siblingRelationship: '', disciplineStyle: '',
      communicationPatterns: '', conflictResolution: '', supportSystem: ''
    },
    familyHistory: {
      mentalHealth: '', neurologicalConditions: '', learningDisabilities: '',
      medicalHistory: '', substanceUse: '', geneticConditions: ''
    },
    observations: {
      physicalAppearance: '', emotionalState: '', cognitiveFunction: '',
      socialInteraction: '', communicationSkills: '', additionalNotes: ''
    }
  });

  useEffect(() => {
    loadPatientAndAnamnesis();
  }, [id, user]);

  const loadPatientAndAnamnesis = async () => {
    if (!id || !user?.id) return;
    
    try {
      setIsLoading(true);
      const patients = await db.getPatients(user.id);
      const foundPatient = patients.find(p => p.id === id);
      
      if (!foundPatient) {
        navigate('/patients');
        return;
      }
      
      setPatient(foundPatient);
      
      const existingAnamnesis = await db.getAnamnesis(user.id, id);
      if (existingAnamnesis) {
        setAnamnesis(existingAnamnesis);
        if (existingAnamnesis.consultation_reason) {
          const data = existingAnamnesis.consultation_reason as Record<string, unknown>;
          if (data.personalData) {
            setFormData(prev => ({ ...prev, ...data }));
          }
        }
      } else {
        setFormData(prev => ({
          ...prev,
          personalData: {
            ...prev.personalData,
            fullName: foundPatient.full_name,
            birthDate: foundPatient.birth_date || '',
            birthPlace: foundPatient.birth_place || '',
            age: foundPatient.age_years?.toString() || '',
            phone: foundPatient.phone || '',
            address: foundPatient.address || ''
          }
        }));
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user?.id || !id) return;
    
    try {
      setIsSaving(true);
      
      await db.saveAnamnesis(user.id, {
        patient_id: id,
        consultation_reason: formData,
        current_illness: formData.consultationReason,
        prenatal_history: {},
        perinatal_history: {},
        postnatal_history: {},
        medical_history: formData.familyHistory,
        neuromuscular_development: {},
        speech_development: {},
        habits_formation: formData.habits,
        behavior: formData.behavior,
        play_behavior: {},
        educational_history: formData.educationalHistory,
        psychosexuality: {},
        parents_attitudes: formData.familyRelationships,
        family_history: formData.familyHistory,
        interview_observations: formData.observations.additionalNotes
      });
      
      await loadPatientAndAnamnesis();
    } catch (error) {
      console.error('Error saving anamnesis:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportDocx = async () => {
    if (!patient || !user) return;

    const clinicalData = {
      patient: {
        name: patient.full_name,
        age: patient.age_years || 0,
        gender: formData.personalData.gender || 'No especificado',
        phone: patient.phone || 'No especificado',
        email: patient.email || 'No especificado',
        address: formData.personalData.address || 'No especificada',
        emergencyContact: formData.personalData.emergencyContact || 'No especificado',
        emergencyPhone: formData.personalData.emergencyPhone || 'No especificado'
      },
      personalHistory: {
        birthDate: formData.personalData.birthDate || 'No especificada',
        birthPlace: patient.birth_place || 'No especificado',
        maritalStatus: formData.familyStructure.maritalStatus || 'No especificado',
        education: formData.educationalHistory.academicPerformance || 'No especificado',
        occupation: 'No especificado',
        religion: 'No especificado'
      },
      familyHistory: {
        father: formData.familyStructure.fatherName || 'No especificado',
        mother: formData.familyStructure.motherName || 'No especificado',
        siblings: formData.familyStructure.siblings || 'No especificado',
        psychiatricHistory: formData.familyHistory.mentalHealth || 'No especificado',
        medicalHistory: formData.familyHistory.medicalHistory || 'No especificado'
      },
      medicalHistory: {
        allergies: 'No especificado',
        medications: 'No especificado',
        surgeries: 'No especificado',
        chronicIllnesses: 'No especificado',
        hospitalizations: 'No especificado'
      },
      psychologicalHistory: {
        previousTreatments: formData.consultationReason.previousTreatments || 'No especificado',
        medications: 'No especificado',
        traumaticEvents: 'No especificado',
        substanceUse: 'No especificado',
        currentSymptoms: formData.consultationReason.mainProblem || 'No especificado'
      },
      mentalStatusExam: {
        appearance: formData.observations.physicalAppearance || 'No especificado',
        behavior: formData.behavior.temperament || 'No especificado',
        speech: 'No especificado',
        mood: formData.observations.emotionalState || 'No especificado',
        affect: 'No especificado',
        thoughtProcess: 'No especificado',
        thoughtContent: 'No especificado',
        perception: 'No especificado',
        cognition: formData.observations.cognitiveFunction || 'No especificado',
        insight: 'No especificado',
        judgment: 'No especificado'
      },
      diagnosis: {
        primary: 'Por determinar',
        secondary: 'No especificado',
        differential: 'No especificado'
      },
      treatmentPlan: {
        goals: 'Por definir',
        interventions: 'Por planificar',
        frequency: 'Por determinar',
        duration: 'Por determinar'
      },
      createdAt: anamnesis?.created_at || new Date().toISOString(),
      psychologist: user.full_name || user.username || 'Psicólogo'
    };

    try {
      await exportClinicalHistoryToDocx(clinicalData);
    } catch (error) {
      console.error('Error exporting clinical history:', error);
      alert('Error al exportar la historia clínica');
    }
  };

  const updateFormData = (section: keyof typeof formData, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando historia clínica...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="flex h-screen bg-gray-50">
        {/* Scrollable Sidebar */}
        <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
          <div className="p-6 border-b border-gray-200">
            <Button variant="ghost" onClick={() => navigate('/patients')} className="mb-4 -ml-2">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver a Pacientes
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Historia Clínica</h1>
            <p className="text-gray-600 mt-1">{patient?.full_name}</p>
            {anamnesis && (
              <Badge variant="default" className="mt-2">
                Guardada el {new Date(anamnesis.updated_at).toLocaleDateString()}
              </Badge>
            )}
          </div>
          
          <ScrollArea className="flex-1 px-4">
            <nav className="py-4 space-y-1">
              {[
                { id: 'personal', label: 'Datos Personales', icon: User },
                { id: 'family', label: 'Estructura Familiar', icon: Users },
                { id: 'consultation', label: 'Motivo de Consulta', icon: FileText },
                { id: 'habits', label: 'Hábitos', icon: Heart },
                { id: 'behavior', label: 'Conducta', icon: Eye },
                { id: 'education', label: 'Historia Educativa', icon: GraduationCap },
                { id: 'relationships', label: 'Relaciones Familiares', icon: Home },
                { id: 'history', label: 'Antecedentes Familiares', icon: Users },
                { id: 'observations', label: 'Observaciones', icon: Eye }
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center px-3 py-2 text-left text-sm font-medium rounded-md transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-100 text-blue-700 border-r-2 border-blue-500'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="mr-3 h-4 w-4" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </ScrollArea>
          
          <div className="p-4 border-t border-gray-200 space-y-2">
            <Button onClick={handleSave} disabled={isSaving} className="w-full">
              {isSaving ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Guardar Historia
            </Button>
            <Button 
              onClick={handleExportDocx} 
              variant="outline" 
              className="w-full"
              disabled={!patient}
            >
              <Download className="h-4 w-4 mr-2" />
              Exportar DOCX
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <ScrollArea className="flex-1 p-6">
            {activeTab === 'personal' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="mr-2 h-5 w-5" />
                    Datos Personales
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">Nombres y Apellidos</Label>
                      <Input
                        id="fullName"
                        value={formData.personalData.fullName}
                        onChange={(e) => updateFormData('personalData', 'fullName', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="birthDate">Fecha de Nacimiento</Label>
                      <Input
                        id="birthDate"
                        type="date"
                        value={formData.personalData.birthDate}
                        onChange={(e) => updateFormData('personalData', 'birthDate', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="age">Edad</Label>
                      <Input
                        id="age"
                        value={formData.personalData.age}
                        onChange={(e) => updateFormData('personalData', 'age', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="gender">Género</Label>
                      <Select value={formData.personalData.gender} onValueChange={(value) => updateFormData('personalData', 'gender', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccione género" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="masculino">Masculino</SelectItem>
                          <SelectItem value="femenino">Femenino</SelectItem>
                          <SelectItem value="otro">Otro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={formData.personalData.phone}
                        onChange={(e) => updateFormData('personalData', 'phone', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="emergencyContact">Contacto de Emergencia</Label>
                      <Input
                        id="emergencyContact"
                        value={formData.personalData.emergencyContact}
                        onChange={(e) => updateFormData('personalData', 'emergencyContact', e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="address">Dirección</Label>
                    <Textarea
                      id="address"
                      value={formData.personalData.address}
                      onChange={(e) => updateFormData('personalData', 'address', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'family' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="mr-2 h-5 w-5" />
                    Estructura Familiar
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900">Información del Padre</h4>
                      <div>
                        <Label htmlFor="fatherName">Nombre del Padre</Label>
                        <Input
                          id="fatherName"
                          value={formData.familyStructure.fatherName}
                          onChange={(e) => updateFormData('familyStructure', 'fatherName', e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="fatherAge">Edad</Label>
                        <Input
                          id="fatherAge"
                          value={formData.familyStructure.fatherAge}
                          onChange={(e) => updateFormData('familyStructure', 'fatherAge', e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="fatherOccupation">Ocupación</Label>
                        <Input
                          id="fatherOccupation"
                          value={formData.familyStructure.fatherOccupation}
                          onChange={(e) => updateFormData('familyStructure', 'fatherOccupation', e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="space-y-4 p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-gray-900">Información de la Madre</h4>
                      <div>
                        <Label htmlFor="motherName">Nombre de la Madre</Label>
                        <Input
                          id="motherName"
                          value={formData.familyStructure.motherName}
                          onChange={(e) => updateFormData('familyStructure', 'motherName', e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="motherAge">Edad</Label>
                        <Input
                          id="motherAge"
                          value={formData.familyStructure.motherAge}
                          onChange={(e) => updateFormData('familyStructure', 'motherAge', e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="motherOccupation">Ocupación</Label>
                        <Input
                          id="motherOccupation"
                          value={formData.familyStructure.motherOccupation}
                          onChange={(e) => updateFormData('familyStructure', 'motherOccupation', e.target.value)}
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="siblings">Hermanos (nombres, edades)</Label>
                    <Textarea
                      id="siblings"
                      value={formData.familyStructure.siblings}
                      onChange={(e) => updateFormData('familyStructure', 'siblings', e.target.value)}
                      placeholder="Información sobre hermanos"
                    />
                  </div>

                  <div>
                    <Label htmlFor="familyDynamics">Dinámica Familiar</Label>
                    <Textarea
                      id="familyDynamics"
                      value={formData.familyStructure.familyDynamics}
                      onChange={(e) => updateFormData('familyStructure', 'familyDynamics', e.target.value)}
                      placeholder="Describe la dinámica familiar"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'consultation' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="mr-2 h-5 w-5" />
                    Motivo de la Consulta
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="mainProblem">Problema Principal</Label>
                    <Textarea
                      id="mainProblem"
                      value={formData.consultationReason.mainProblem}
                      onChange={(e) => updateFormData('consultationReason', 'mainProblem', e.target.value)}
                      placeholder="Descripción del problema principal"
                    />
                  </div>
                  <div>
                    <Label htmlFor="whenStarted">¿Cuándo comenzó?</Label>
                    <Textarea
                      id="whenStarted"
                      value={formData.consultationReason.whenStarted}
                      onChange={(e) => updateFormData('consultationReason', 'whenStarted', e.target.value)}
                      placeholder="Inicio del problema"
                    />
                  </div>
                  <div>
                    <Label htmlFor="evolution">Evolución del problema</Label>
                    <Textarea
                      id="evolution"
                      value={formData.consultationReason.evolution}
                      onChange={(e) => updateFormData('consultationReason', 'evolution', e.target.value)}
                      placeholder="¿Cómo ha evolucionado?"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'habits' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="mr-2 h-5 w-5" />
                    Hábitos de Alimentación, Higiene, Sueño e Independencia
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="appetite">Hábitos de Alimentación</Label>
                    <Textarea
                      id="appetite"
                      value={formData.habits.appetite}
                      onChange={(e) => updateFormData('habits', 'appetite', e.target.value)}
                      placeholder="Apetito, horarios, preferencias alimentarias"
                    />
                  </div>
                  <div>
                    <Label htmlFor="personalCare">Hábitos de Higiene</Label>
                    <Textarea
                      id="personalCare"
                      value={formData.habits.personalCare}
                      onChange={(e) => updateFormData('habits', 'personalCare', e.target.value)}
                      placeholder="Baño, cepillado de dientes, cuidado personal"
                    />
                  </div>
                  <div>
                    <Label htmlFor="sleepHours">Hábitos de Sueño</Label>
                    <Textarea
                      id="sleepHours"
                      value={formData.habits.sleepHours}
                      onChange={(e) => updateFormData('habits', 'sleepHours', e.target.value)}
                      placeholder="Horas de sueño, horarios, dificultades"
                    />
                  </div>
                  <div>
                    <Label htmlFor="independence">Independencia</Label>
                    <Textarea
                      id="independence"
                      value={formData.habits.independence}
                      onChange={(e) => updateFormData('habits', 'independence', e.target.value)}
                      placeholder="Nivel de autonomía en vestirse, cuidado personal, tareas del hogar"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'behavior' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="mr-2 h-5 w-5" />
                    Conducta
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="temperament">Temperamento General</Label>
                    <Textarea
                      id="temperament"
                      value={formData.behavior.temperament}
                      onChange={(e) => updateFormData('behavior', 'temperament', e.target.value)}
                      placeholder="Describe el temperamento y personalidad"
                    />
                  </div>
                  <div>
                    <Label htmlFor="socialBehavior">Comportamiento Social</Label>
                    <Textarea
                      id="socialBehavior"
                      value={formData.behavior.socialBehavior}
                      onChange={(e) => updateFormData('behavior', 'socialBehavior', e.target.value)}
                      placeholder="Cómo se relaciona con otros"
                    />
                  </div>
                  <div>
                    <Label htmlFor="attention">Atención y Concentración</Label>
                    <Textarea
                      id="attention"
                      value={formData.behavior.attention}
                      onChange={(e) => updateFormData('behavior', 'attention', e.target.value)}
                      placeholder="Capacidad de atención y concentración"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'education' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <GraduationCap className="mr-2 h-5 w-5" />
                    Historia Educativa
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="currentGrade">Grado Actual</Label>
                      <Input
                        id="currentGrade"
                        value={formData.educationalHistory.currentGrade}
                        onChange={(e) => updateFormData('educationalHistory', 'currentGrade', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="schoolName">Institución Educativa</Label>
                      <Input
                        id="schoolName"
                        value={formData.educationalHistory.schoolName}
                        onChange={(e) => updateFormData('educationalHistory', 'schoolName', e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="academicPerformance">Rendimiento Académico</Label>
                    <Textarea
                      id="academicPerformance"
                      value={formData.educationalHistory.academicPerformance}
                      onChange={(e) => updateFormData('educationalHistory', 'academicPerformance', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="learningDifficulties">Dificultades de Aprendizaje</Label>
                    <Textarea
                      id="learningDifficulties"
                      value={formData.educationalHistory.learningDifficulties}
                      onChange={(e) => updateFormData('educationalHistory', 'learningDifficulties', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'relationships' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Home className="mr-2 h-5 w-5" />
                    Relaciones Familiares
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="parentRelationship">Relación con los Padres</Label>
                    <Textarea
                      id="parentRelationship"
                      value={formData.familyRelationships.parentRelationship}
                      onChange={(e) => updateFormData('familyRelationships', 'parentRelationship', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="disciplineStyle">Estilo de Disciplina</Label>
                    <Textarea
                      id="disciplineStyle"
                      value={formData.familyRelationships.disciplineStyle}
                      onChange={(e) => updateFormData('familyRelationships', 'disciplineStyle', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'history' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="mr-2 h-5 w-5" />
                    Antecedentes Familiares
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="mentalHealth">Antecedentes de Salud Mental</Label>
                    <Textarea
                      id="mentalHealth"
                      value={formData.familyHistory.mentalHealth}
                      onChange={(e) => updateFormData('familyHistory', 'mentalHealth', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="medicalHistory">Antecedentes Médicos</Label>
                    <Textarea
                      id="medicalHistory"
                      value={formData.familyHistory.medicalHistory}
                      onChange={(e) => updateFormData('familyHistory', 'medicalHistory', e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {activeTab === 'observations' && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Eye className="mr-2 h-5 w-5" />
                    Observaciones
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="physicalAppearance">Apariencia Física</Label>
                    <Textarea
                      id="physicalAppearance"
                      value={formData.observations.physicalAppearance}
                      onChange={(e) => updateFormData('observations', 'physicalAppearance', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="emotionalState">Estado Emocional</Label>
                    <Textarea
                      id="emotionalState"
                      value={formData.observations.emotionalState}
                      onChange={(e) => updateFormData('observations', 'emotionalState', e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="additionalNotes">Observaciones Generales</Label>
                    <Textarea
                      id="additionalNotes"
                      value={formData.observations.additionalNotes}
                      onChange={(e) => updateFormData('observations', 'additionalNotes', e.target.value)}
                      className="min-h-[120px]"
                    />
                  </div>
                </CardContent>
              </Card>
            )}
          </ScrollArea>
        </div>
      </div>
    </Layout>
  );
}