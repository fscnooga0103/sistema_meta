import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  DollarSign,
  CreditCard,
  TrendingUp,
  Calendar,
  User,
  Plus,
  Search,
  Download,
  FileText
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { db, Patient } from '@/lib/database';
import { exportFinancialReportToXlsx } from '@/utils/documentExports';

interface Payment {
  id: string;
  patient_id: string;
  user_id: string;
  amount: number;
  currency: string;
  payment_method: 'cash' | 'card' | 'transfer' | 'check';
  session_type: string;
  payment_date: string;
  description?: string;
  status: 'pending' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
}

export default function Finances() {
  const { user } = useAuth();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<Payment[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showNewPayment, setShowNewPayment] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const [newPayment, setNewPayment] = useState({
    patient_id: '',
    amount: '',
    currency: 'USD',
    payment_method: 'cash' as const,
    session_type: 'Sesión Individual',
    payment_date: new Date().toISOString().split('T')[0],
    description: ''
  });

  useEffect(() => {
    loadData();
  }, [user]);

  useEffect(() => {
    filterPayments();
  }, [payments, searchTerm, statusFilter]);

  const loadData = async () => {
    if (!user?.id) return;
    
    try {
      setIsLoading(true);
      const [paymentsData, patientsData] = await Promise.all([
        getPayments(user.id),
        db.getPatients(user.id)
      ]);
      
      setPayments(paymentsData);
      setPatients(patientsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Simulate payment storage using localStorage
  const getPayments = async (userId: string): Promise<Payment[]> => {
    try {
      const data = localStorage.getItem(`psicoManager_payments_${userId}`);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  };

  const createPayment = async (userId: string, paymentData: Omit<Payment, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<Payment> => {
    const now = new Date().toISOString();
    const newPayment: Payment = {
      ...paymentData,
      id: 'pay_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36),
      user_id: userId,
      status: 'completed',
      created_at: now,
      updated_at: now
    };

    const payments = await getPayments(userId);
    payments.unshift(newPayment);
    localStorage.setItem(`psicoManager_payments_${userId}`, JSON.stringify(payments));
    return newPayment;
  };

  const filterPayments = () => {
    let filtered = payments;
    
    if (searchTerm) {
      filtered = filtered.filter(payment => {
        const patient = patients.find(p => p.id === payment.patient_id);
        return patient?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
               payment.description?.toLowerCase().includes(searchTerm.toLowerCase());
      });
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(payment => payment.status === statusFilter);
    }
    
    setFilteredPayments(filtered);
  };

  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id || !newPayment.patient_id || !newPayment.amount) return;

    try {
      setIsSaving(true);
      
      await createPayment(user.id, {
        patient_id: newPayment.patient_id,
        amount: parseFloat(newPayment.amount),
        currency: newPayment.currency,
        payment_method: newPayment.payment_method,
        session_type: newPayment.session_type,
        payment_date: newPayment.payment_date,
        description: newPayment.description
      });
      
      // Reset form
      setNewPayment({
        patient_id: '',
        amount: '',
        currency: 'USD',
        payment_method: 'cash',
        session_type: 'Sesión Individual',
        payment_date: new Date().toISOString().split('T')[0],
        description: ''
      });
      
      setShowNewPayment(false);
      await loadData();
    } catch (error) {
      console.error('Error adding payment:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const exportFinancialReport = () => {
    const totalIncome = payments.reduce((sum, payment) => sum + payment.amount, 0);
    const monthlyIncome = payments.filter(p => {
      const paymentDate = new Date(p.payment_date);
      const now = new Date();
      return paymentDate.getMonth() === now.getMonth() && paymentDate.getFullYear() === now.getFullYear();
    }).reduce((sum, payment) => sum + payment.amount, 0);

    const reportContent = `
REPORTE FINANCIERO
==================

Fecha del reporte: ${new Date().toLocaleDateString()}
Psicólogo: ${user?.full_name || 'No especificado'}

RESUMEN FINANCIERO:
- Total ingresos: ${totalIncome.toFixed(2)} ${payments[0]?.currency || 'USD'}
- Ingresos este mes: ${monthlyIncome.toFixed(2)} ${payments[0]?.currency || 'USD'}
- Total de pagos registrados: ${payments.length}
- Pagos este mes: ${payments.filter(p => {
  const paymentDate = new Date(p.payment_date);
  const now = new Date();
  return paymentDate.getMonth() === now.getMonth() && paymentDate.getFullYear() === now.getFullYear();
}).length}

DETALLE DE PAGOS:
${payments.map(payment => {
  const patient = patients.find(p => p.id === payment.patient_id);
  return `
Fecha: ${new Date(payment.payment_date).toLocaleDateString()}
Paciente: ${patient?.full_name || 'No encontrado'}
Tipo: ${payment.session_type}
Monto: ${payment.amount.toFixed(2)} ${payment.currency}
Método: ${payment.payment_method}
Estado: ${payment.status}
---`;
}).join('')}

RESUMEN POR MÉTODO DE PAGO:
${Object.entries(
  payments.reduce((acc, p) => {
    acc[p.payment_method] = (acc[p.payment_method] || 0) + p.amount;
    return acc;
  }, {} as Record<string, number>)
).map(([method, total]) => `${method}: ${total.toFixed(2)} ${payments[0]?.currency || 'USD'}`).join('\n')}
`;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte_financiero_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const exportFinancialReportXlsx = () => {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    
    const totalIncome = payments.reduce((sum, payment) => sum + payment.amount, 0);
    const pendingPayments = payments.filter(p => p.status === 'pending').reduce((sum, payment) => sum + payment.amount, 0);
    const averageSessionValue = payments.length > 0 ? totalIncome / payments.length : 0;

    const financialData = {
      period: {
        start: startOfMonth.toLocaleDateString('es-ES'),
        end: endOfMonth.toLocaleDateString('es-ES')
      },
      transactions: payments.map(payment => {
        const patient = patients.find(p => p.id === payment.patient_id);
        return {
          date: payment.payment_date,
          patient: patient?.full_name || 'Paciente no encontrado',
          service: payment.session_type,
          amount: payment.amount,
          status: payment.status === 'completed' ? 'Completado' : payment.status === 'pending' ? 'Pendiente' : 'Cancelado',
          paymentMethod: getPaymentMethodLabel(payment.payment_method)
        };
      }),
      summary: {
        totalIncome,
        totalSessions: payments.length,
        averageSessionValue,
        pendingPayments
      },
      psychologist: user?.full_name || user?.username || 'Psicólogo',
      generatedAt: new Date().toISOString()
    };

    try {
      exportFinancialReportToXlsx(financialData);
    } catch (error) {
      console.error('Error exporting financial report:', error);
      alert('Error al exportar el reporte financiero');
    }
  };

  const getPatientName = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.full_name || 'Paciente no encontrado';
  };

  const getPaymentMethodLabel = (method: string) => {
    const labels = {
      cash: 'Efectivo',
      card: 'Tarjeta',
      transfer: 'Transferencia',
      check: 'Cheque'
    };
    return labels[method as keyof typeof labels] || method;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const totalIncome = payments.reduce((sum, payment) => sum + payment.amount, 0);
  const monthlyIncome = payments.filter(p => {
    const paymentDate = new Date(p.payment_date);
    const now = new Date();
    return paymentDate.getMonth() === now.getMonth() && paymentDate.getFullYear() === now.getFullYear();
  }).reduce((sum, payment) => sum + payment.amount, 0);

  const weeklyIncome = payments.filter(p => {
    const paymentDate = new Date(p.payment_date);
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    return paymentDate >= weekAgo && paymentDate <= now;
  }).reduce((sum, payment) => sum + payment.amount, 0);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando información financiera...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestión Financiera</h1>
            <p className="text-gray-600">Administra los pagos y genera reportes financieros</p>
          </div>
          
          <div className="flex space-x-2">
            <Button variant="outline" onClick={exportFinancialReport}>
              <Download className="mr-2 h-4 w-4" />
              Exportar TXT
            </Button>
            <Button onClick={exportFinancialReportXlsx}>
              <Download className="mr-2 h-4 w-4" />
              Exportar Excel
            </Button>
            
            <Dialog open={showNewPayment} onOpenChange={setShowNewPayment}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Registrar Pago
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Registrar Nuevo Pago</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddPayment} className="space-y-4">
                  <div>
                    <Label htmlFor="patient">Paciente</Label>
                    <Select value={newPayment.patient_id} onValueChange={(value) => setNewPayment(prev => ({ ...prev, patient_id: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Seleccione un paciente" />
                      </SelectTrigger>
                      <SelectContent>
                        {patients.map(patient => (
                          <SelectItem key={patient.id} value={patient.id}>
                            {patient.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="amount">Monto</Label>
                      <Input
                        id="amount"
                        type="number"
                        step="0.01"
                        value={newPayment.amount}
                        onChange={(e) => setNewPayment(prev => ({ ...prev, amount: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="currency">Moneda</Label>
                      <Select value={newPayment.currency} onValueChange={(value) => setNewPayment(prev => ({ ...prev, currency: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD (Dólares)</SelectItem>
                          <SelectItem value="PEN">PEN (Soles)</SelectItem>
                          <SelectItem value="EUR">EUR (Euros)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="payment_method">Método de Pago</Label>
                      <Select value={newPayment.payment_method} onValueChange={(value: 'cash' | 'card' | 'transfer' | 'check') => setNewPayment(prev => ({ ...prev, payment_method: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Efectivo</SelectItem>
                          <SelectItem value="card">Tarjeta</SelectItem>
                          <SelectItem value="transfer">Transferencia</SelectItem>
                          <SelectItem value="check">Cheque</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="session_type">Tipo de Sesión</Label>
                      <Select value={newPayment.session_type} onValueChange={(value) => setNewPayment(prev => ({ ...prev, session_type: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Sesión Individual">Sesión Individual</SelectItem>
                          <SelectItem value="Evaluación Inicial">Evaluación Inicial</SelectItem>
                          <SelectItem value="Sesión Familiar">Sesión Familiar</SelectItem>
                          <SelectItem value="Seguimiento">Seguimiento</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="payment_date">Fecha de Pago</Label>
                    <Input
                      id="payment_date"
                      type="date"
                      value={newPayment.payment_date}
                      onChange={(e) => setNewPayment(prev => ({ ...prev, payment_date: e.target.value }))}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Descripción (opcional)</Label>
                    <Textarea
                      id="description"
                      value={newPayment.description}
                      onChange={(e) => setNewPayment(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Notas adicionales sobre el pago"
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowNewPayment(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" disabled={isSaving || !newPayment.patient_id || !newPayment.amount}>
                      {isSaving ? 'Guardando...' : 'Registrar Pago'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Financial Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Ingresos</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalIncome.toFixed(2)} USD</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Este Mes</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${monthlyIncome.toFixed(2)} USD</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Esta Semana</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${weeklyIncome.toFixed(2)} USD</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pagos</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{payments.length}</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por paciente o descripción..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filtrar por estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="completed">Completados</SelectItem>
              <SelectItem value="pending">Pendientes</SelectItem>
              <SelectItem value="cancelled">Cancelados</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Payments List */}
        <Card>
          <CardHeader>
            <CardTitle>Historial de Pagos</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredPayments.length > 0 ? (
              <div className="space-y-4">
                {filteredPayments.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4 text-gray-500" />
                        <span className="font-medium">{getPatientName(payment.patient_id)}</span>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">{payment.session_type}</p>
                        <p className="text-xs text-gray-500">{new Date(payment.payment_date).toLocaleDateString('es-ES')}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="font-bold">{payment.amount.toFixed(2)} {payment.currency}</div>
                        <div className="text-sm text-gray-600">{getPaymentMethodLabel(payment.payment_method)}</div>
                      </div>
                      <Badge className={getStatusColor(payment.status)}>
                        {payment.status === 'completed' ? 'completado' : payment.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <DollarSign className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                <p>No hay pagos registrados</p>
                {(!searchTerm && statusFilter === 'all') && (
                  <Button onClick={() => setShowNewPayment(true)} className="mt-4">
                    <Plus className="h-4 w-4 mr-2" />
                    Registrar Primer Pago
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}