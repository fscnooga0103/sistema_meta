import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Settings as SettingsIcon,
  Upload,
  Save,
  RefreshCw,
  User,
  Building,
  Palette
} from 'lucide-react';

export default function Settings() {
  const [settings, setSettings] = useState({
    systemName: 'PsicoManager',
    centerName: '',
    psychologistName: '',
    logo: '',
    theme: 'default',
    description: 'Sistema de Gestión Psicológica'
  });
  const [savedMessage, setSavedMessage] = useState('');
  const [currentUser, setCurrentUser] = useState<{ username: string; role: string } | null>(null);

  useEffect(() => {
    // Load current user
    const userStr = localStorage.getItem('psicoManager_user');
    if (userStr) {
      setCurrentUser(JSON.parse(userStr));
    }

    // Load saved settings
    const savedSettings = localStorage.getItem('psicoManager_settings');
    if (savedSettings) {
      setSettings({ ...settings, ...JSON.parse(savedSettings) });
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('psicoManager_settings', JSON.stringify(settings));
    setSavedMessage('Configuración guardada exitosamente');
    setTimeout(() => setSavedMessage(''), 3000);
    
    // Reload the page to apply changes
    window.location.reload();
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSettings({
          ...settings,
          logo: event.target?.result as string
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const resetToDefault = () => {
    const defaultSettings = {
      systemName: 'PsicoManager',
      centerName: '',
      psychologistName: '',
      logo: '',
      theme: 'default',
      description: 'Sistema de Gestión Psicológica'
    };
    setSettings(defaultSettings);
    localStorage.removeItem('psicoManager_settings');
    setSavedMessage('Configuración restablecida a valores por defecto');
    setTimeout(() => setSavedMessage(''), 3000);
  };

  // Check if user is admin
  const isAdmin = currentUser?.role === 'admin';

  if (!isAdmin) {
    return (
      <Layout>
        <div className="text-center py-16">
          <div className="mx-auto h-24 w-24 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <SettingsIcon className="h-12 w-12 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Acceso Restringido</h2>
          <p className="text-gray-600">Solo los administradores pueden acceder a esta sección.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Configuración del Sistema</h1>
          <p className="text-gray-600">Personaliza la apariencia y configuración de PsicoManager</p>
        </div>

        {savedMessage && (
          <Alert>
            <AlertDescription>{savedMessage}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="general" className="w-full">
          <TabsList>
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="branding">Marca e Identidad</TabsTrigger>
            <TabsTrigger value="preview">Vista Previa</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <SettingsIcon className="mr-2 h-5 w-5" />
                  Configuración General
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="systemName">Nombre del Sistema</Label>
                    <Input
                      id="systemName"
                      value={settings.systemName}
                      onChange={(e) => setSettings({ ...settings, systemName: e.target.value })}
                      placeholder="PsicoManager"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="centerName">Nombre del Centro</Label>
                    <Input
                      id="centerName"
                      value={settings.centerName}
                      onChange={(e) => setSettings({ ...settings, centerName: e.target.value })}
                      placeholder="Centro de Psicología Integral"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="psychologistName">Nombre del Psicólogo</Label>
                    <Input
                      id="psychologistName"
                      value={settings.psychologistName}
                      onChange={(e) => setSettings({ ...settings, psychologistName: e.target.value })}
                      placeholder="Dr. Juan Pérez"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    value={settings.description}
                    onChange={(e) => setSettings({ ...settings, description: e.target.value })}
                    placeholder="Descripción del sistema o centro"
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="branding" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Palette className="mr-2 h-5 w-5" />
                  Marca e Identidad Visual
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <Label>Logo del Sistema</Label>
                  <div className="flex items-center space-x-4">
                    {settings.logo ? (
                      <img 
                        src={settings.logo} 
                        alt="Logo" 
                        className="h-16 w-16 object-contain border rounded-lg p-2"
                      />
                    ) : (
                      <div className="h-16 w-16 bg-gray-100 border rounded-lg flex items-center justify-center">
                        <Building className="h-8 w-8 text-gray-400" />
                      </div>
                    )}
                    <div className="flex flex-col space-y-2">
                      <Button variant="outline" onClick={() => document.getElementById('logoUpload')?.click()}>
                        <Upload className="mr-2 h-4 w-4" />
                        Subir Logo
                      </Button>
                      <input
                        id="logoUpload"
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                      {settings.logo && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => setSettings({ ...settings, logo: '' })}
                        >
                          Eliminar Logo
                        </Button>
                      )}
                    </div>
                  </div>
                  <p className="text-sm text-gray-500">
                    Sube un logo en formato PNG, JPG o SVG. Tamaño recomendado: 200x200px
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Vista Previa del Dashboard</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded-lg p-6 bg-gradient-to-br from-gray-50 to-blue-50">
                  <div className="flex items-center space-x-4 mb-6">
                    {settings.logo ? (
                      <img 
                        src={settings.logo} 
                        alt="Logo" 
                        className="h-12 w-12 object-contain"
                      />
                    ) : (
                      <div className="h-12 w-12 bg-blue-600 rounded-full flex items-center justify-center">
                        <User className="h-6 w-6 text-white" />
                      </div>
                    )}
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900">
                        {settings.systemName || 'PsicoManager'}
                      </h2>
                      <p className="text-gray-600">
                        {settings.centerName || settings.psychologistName || settings.description}
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {['Pacientes', 'Citas Hoy', 'Ingresos', 'Sesiones'].map((item, index) => (
                      <div key={index} className="bg-white p-4 rounded-lg shadow-sm">
                        <p className="text-sm text-gray-600">{item}</p>
                        <p className="text-xl font-bold">
                          {index === 0 ? '24' : index === 1 ? '6' : index === 2 ? '$4,800' : '142'}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex justify-between">
          <Button variant="outline" onClick={resetToDefault}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Restablecer por Defecto
          </Button>
          <Button onClick={handleSave}>
            <Save className="mr-2 h-4 w-4" />
            Guardar Configuración
          </Button>
        </div>
      </div>
    </Layout>
  );
}