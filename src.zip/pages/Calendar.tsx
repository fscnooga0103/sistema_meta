import { useState, useEffect } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar as CalendarIcon,
  Clock,
  User,
  Plus,
  ChevronLeft,
  ChevronRight,
  Edit,
  Trash2
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { db, Patient, Appointment } from '@/lib/database';

export default function Calendar() {
  const { user } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showNewAppointment, setShowNewAppointment] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  // Form data for new appointment
  const [formData, setFormData] = useState({
    patient_id: '',
    appointment_date: new Date().toISOString().split('T')[0],
    appointment_time: '09:00',
    duration: 60,
    appointment_type: 'Sesión Individual',
    notes: ''
  });

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user?.id) return;
    
    try {
      setIsLoading(true);
      const [appointmentsData, patientsData] = await Promise.all([
        db.getAppointments(user.id),
        db.getPatients(user.id)
      ]);
      
      setAppointments(appointmentsData);
      setPatients(patientsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateAppointment = async () => {
    if (!user?.id || !formData.patient_id) return;
    
    try {
      setIsSaving(true);
      await db.createAppointment(user.id, {
        patient_id: formData.patient_id,
        appointment_date: formData.appointment_date,
        appointment_time: formData.appointment_time,
        duration: formData.duration,
        appointment_type: formData.appointment_type,
        status: 'scheduled',
        notes: formData.notes,
        reminder_sent: false
      });
      
      // Reset form and reload data
      setFormData({
        patient_id: '',
        appointment_date: new Date().toISOString().split('T')[0],
        appointment_time: '09:00',
        duration: 60,
        appointment_type: 'Sesión Individual',
        notes: ''
      });
      setShowNewAppointment(false);
      await loadData();
      
      // Trigger dashboard refresh with more details
      window.dispatchEvent(new CustomEvent('appointmentCreated', {
        detail: { 
          date: formData.appointment_date,
          time: formData.appointment_time,
          patient_id: formData.patient_id
        }
      }));
      
      // Force immediate dashboard update
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('forceRefresh'));
      }, 100);
    } catch (error) {
      console.error('Error creating appointment:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const updateAppointmentStatus = async (appointmentId: string, newStatus: string) => {
    if (!user?.id) return;

    try {
      setIsUpdating(true);
      await db.updateAppointment(user.id, appointmentId, { status: newStatus as any });
      await loadData();
      
      // Trigger dashboard refresh with details
      window.dispatchEvent(new CustomEvent('appointmentUpdated', {
        detail: { 
          appointmentId,
          newStatus
        }
      }));
      
      // Force immediate dashboard update
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('forceRefresh'));
      }, 100);
    } catch (error) {
      console.error('Error updating appointment:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (direction === 'prev') {
      newDate.setMonth(currentDate.getMonth() - 1);
    } else {
      newDate.setMonth(currentDate.getMonth() + 1);
    }
    setCurrentDate(newDate);
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('es-ES', { 
      month: 'long', 
      year: 'numeric' 
    }).format(date);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      case 'no_show': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const todaysAppointments = appointments.filter(apt => 
    apt.appointment_date === new Date().toISOString().split('T')[0]
  );

  const selectedDateAppointments = appointments.filter(apt => 
    apt.appointment_date === selectedDate.toISOString().split('T')[0]
  );

  const getPatientName = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    return patient?.full_name || 'Paciente no encontrado';
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando agenda...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Agenda</h1>
            <p className="text-gray-600">Gestiona tus citas y horarios</p>
          </div>
          
          <Dialog open={showNewAppointment} onOpenChange={setShowNewAppointment}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nueva Cita
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Programar Nueva Cita</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="patient">Paciente</Label>
                  <Select value={formData.patient_id} onValueChange={(value) => setFormData(prev => ({ ...prev, patient_id: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione un paciente" />
                    </SelectTrigger>
                    <SelectContent>
                      {patients.map(patient => (
                        <SelectItem key={patient.id} value={patient.id}>
                          {patient.full_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date">Fecha</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.appointment_date}
                      onChange={(e) => setFormData(prev => ({ ...prev, appointment_date: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="time">Hora</Label>
                    <Input
                      id="time"
                      type="time"
                      value={formData.appointment_time}
                      onChange={(e) => setFormData(prev => ({ ...prev, appointment_time: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="duration">Duración (minutos)</Label>
                    <Select value={formData.duration.toString()} onValueChange={(value) => setFormData(prev => ({ ...prev, duration: parseInt(value) }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 minutos</SelectItem>
                        <SelectItem value="45">45 minutos</SelectItem>
                        <SelectItem value="60">60 minutos</SelectItem>
                        <SelectItem value="90">90 minutos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="type">Tipo de Cita</Label>
                    <Select value={formData.appointment_type} onValueChange={(value) => setFormData(prev => ({ ...prev, appointment_type: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Sesión Individual">Sesión Individual</SelectItem>
                        <SelectItem value="Evaluación Inicial">Evaluación Inicial</SelectItem>
                        <SelectItem value="Sesión Familiar">Sesión Familiar</SelectItem>
                        <SelectItem value="Seguimiento">Seguimiento</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="notes">Notas</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Notas adicionales para la cita"
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowNewAppointment(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleCreateAppointment} disabled={isSaving || !formData.patient_id}>
                    {isSaving ? 'Guardando...' : 'Programar Cita'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg capitalize">
                    {formatDate(currentDate)}
                  </CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-1 mb-4">
                  {['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'].map(day => (
                    <div key={day} className="text-center text-sm font-medium text-gray-500 p-2">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 35 }, (_, i) => {
                    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), i - 6);
                    const isCurrentMonth = date.getMonth() === currentDate.getMonth();
                    const isToday = date.toDateString() === new Date().toDateString();
                    const hasAppointments = appointments.some(apt => apt.appointment_date === date.toISOString().split('T')[0]);
                    
                    return (
                      <button
                        key={i}
                        className={`
                          p-2 text-sm rounded-lg transition-colors
                          ${isCurrentMonth ? 'text-gray-900' : 'text-gray-400'}
                          ${isToday ? 'bg-blue-100 text-blue-900' : 'hover:bg-gray-100'}
                          ${hasAppointments ? 'bg-green-50 text-green-900' : ''}
                        `}
                        onClick={() => setSelectedDate(date)}
                      >
                        {date.getDate()}
                        {hasAppointments && (
                          <div className="w-1 h-1 bg-green-500 rounded-full mx-auto mt-1" />
                        )}
                      </button>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Appointments */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CalendarIcon className="mr-2 h-5 w-5" />
                  Citas del Día - {selectedDate.toLocaleDateString('es-ES')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedDateAppointments.length > 0 ? (
                    selectedDateAppointments.map((appointment) => (
                      <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-gray-500" />
                            <span className="font-medium">{appointment.appointment_time}</span>
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <User className="h-4 w-4 text-gray-500" />
                              <span className="font-medium">{getPatientName(appointment.patient_id)}</span>
                            </div>
                            <p className="text-sm text-gray-600">{appointment.appointment_type}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge className={getStatusColor(appointment.status)}>
                            {appointment.status === 'scheduled' ? 'programada' : 
                             appointment.status === 'completed' ? 'completada' : 
                             appointment.status === 'cancelled' ? 'cancelada' : 
                             appointment.status === 'no_show' ? 'no asistió' : appointment.status}
                          </Badge>
                          <span className="text-sm text-gray-500">{appointment.duration} min</span>
                          {appointment.status === 'scheduled' && (
                            <div className="flex space-x-1">
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => updateAppointmentStatus(appointment.id, 'completed')}
                                disabled={isUpdating}
                                className="text-xs"
                              >
                                Completar
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => updateAppointmentStatus(appointment.id, 'cancelled')}
                                disabled={isUpdating}
                                className="text-xs"
                              >
                                Cancelar
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <CalendarIcon className="mx-auto h-12 w-12 text-gray-300 mb-4" />
                      <p>No hay citas programadas para esta fecha</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Today's Summary */}
            {todaysAppointments.length > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Resumen de Hoy</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-blue-600">{todaysAppointments.length}</div>
                      <div className="text-sm text-gray-600">Total Citas</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-600">
                        {todaysAppointments.filter(apt => apt.status === 'completed').length}
                      </div>
                      <div className="text-sm text-gray-600">Completadas</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-orange-600">
                        {todaysAppointments.filter(apt => apt.status === 'scheduled').length}
                      </div>
                      <div className="text-sm text-gray-600">Pendientes</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}