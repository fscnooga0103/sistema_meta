import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Users, FileText, Calendar, MoreHorizontal } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { db, Patient } from '@/lib/database';

export default function Patients() {
  const { user } = useAuth();
  const [patients, setPatients] = useState<Patient[]>([]);
  const [filteredPatients, setFilteredPatients] = useState<Patient[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isAddingPatient, setIsAddingPatient] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const [newPatient, setNewPatient] = useState({
    full_name: '',
    birth_date: '',
    birth_place: '',
    age_years: '',
    age_months: '',
    education_level: '',
    phone: '',
    email: '',
    address: '',
    emergency_contact_name: '',
    emergency_contact_phone: '',
    status: 'active' as const
  });

  useEffect(() => {
    const loadPatientsWithTimeout = async () => {
      if (!user) {
        console.log('User not available yet');
        return;
      }
      
      // Add timeout to prevent infinite loading
      const timeout = setTimeout(() => {
        console.warn('Loading patients timeout');
        setIsLoading(false);
      }, 5000);
      
      try {
        await loadPatients();
      } finally {
        clearTimeout(timeout);
      }
    };
    
    loadPatientsWithTimeout();
  }, [user]);

  useEffect(() => {
    filterPatients();
  }, [patients, searchTerm, statusFilter]);

  const loadPatients = async () => {
    if (!user?.id) {
      console.log('No user ID found:', user);
      setIsLoading(false);
      return;
    }
    
    try {
      setIsLoading(true);
      console.log('Loading patients for user:', user.id);
      const patientsData = await db.getPatients(user.id);
      console.log('Patients loaded:', patientsData);
      setPatients(patientsData);
    } catch (error) {
      console.error('Error loading patients:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterPatients = () => {
    let filtered = patients;
    
    if (searchTerm) {
      filtered = filtered.filter(patient =>
        patient.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        patient.phone?.includes(searchTerm) ||
        patient.email?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(patient => patient.status === statusFilter);
    }
    
    setFilteredPatients(filtered);
  };

  const handleAddPatient = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.id) return;

    try {
      const patientData = {
        ...newPatient,
        age_years: newPatient.age_years ? parseInt(newPatient.age_years) : undefined,
        age_months: newPatient.age_months ? parseInt(newPatient.age_months) : undefined
      };

      await db.createPatient(user.id, patientData);
      await loadPatients();
      
      // Reset form
      setNewPatient({
        full_name: '',
        birth_date: '',
        birth_place: '',
        age_years: '',
        age_months: '',
        education_level: '',
        phone: '',
        email: '',
        address: '',
        emergency_contact_name: '',
        emergency_contact_phone: '',
        status: 'active'
      });
      setIsAddingPatient(false);
    } catch (error) {
      console.error('Error adding patient:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: 'Activo', variant: 'default' as const },
      inactive: { label: 'Inactivo', variant: 'secondary' as const },
      discharged: { label: 'Alta', variant: 'outline' as const }
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.active;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const updatePatientStatus = async (patientId: string, status: 'active' | 'inactive' | 'discharged') => {
    if (!user?.id) return;
    
    try {
      await db.updatePatient(user.id, patientId, { status });
      await loadPatients();
    } catch (error) {
      console.error('Error updating patient status:', error);
    }
  };

  const getAge = (patient: Patient) => {
    if (patient.age_years || patient.age_months) {
      const years = patient.age_years || 0;
      const months = patient.age_months || 0;
      return `${years}a ${months}m`;
    }
    if (patient.birth_date) {
      const birthDate = new Date(patient.birth_date);
      const today = new Date();
      const diffTime = Math.abs(today.getTime() - birthDate.getTime());
      const diffYears = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 365));
      return `${diffYears} años`;
    }
    return 'No especificada';
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Cargando pacientes...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Gestión de Pacientes</h1>
            <p className="text-gray-600">Administre la información y historiales de sus pacientes</p>
          </div>
          
          <Dialog open={isAddingPatient} onOpenChange={setIsAddingPatient}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Paciente
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh]">
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Paciente</DialogTitle>
                <DialogDescription>
                  Complete la información básica del paciente. Podrá agregar la historia clínica completa después.
                </DialogDescription>
              </DialogHeader>
              
              <div className="flex gap-6">
                {/* Navigation Sidebar */}
                <div className="w-48 flex-shrink-0">
                  <div className="sticky top-0">
                    <h4 className="font-medium mb-3 text-sm text-gray-700">Secciones del Formulario</h4>
                    <nav className="space-y-1">
                      <button
                        type="button"
                        onClick={() => document.getElementById('info-personal')?.scrollIntoView({ behavior: 'smooth' })}
                        className="w-full text-left px-2 py-1 text-xs rounded hover:bg-gray-100 transition-colors"
                      >
                        Información Personal
                      </button>
                      <button
                        type="button"
                        onClick={() => document.getElementById('info-contacto')?.scrollIntoView({ behavior: 'smooth' })}
                        className="w-full text-left px-2 py-1 text-xs rounded hover:bg-gray-100 transition-colors"
                      >
                        Información de Contacto
                      </button>
                      <button
                        type="button"
                        onClick={() => document.getElementById('emergencia')?.scrollIntoView({ behavior: 'smooth' })}
                        className="w-full text-left px-2 py-1 text-xs rounded hover:bg-gray-100 transition-colors"
                      >
                        Contacto de Emergencia
                      </button>
                    </nav>
                  </div>
                </div>

                {/* Form Content */}
                <div className="flex-1 max-h-[60vh] overflow-y-auto pr-2">
                  <form onSubmit={handleAddPatient}>
                    {/* Información Personal */}
                    <div id="info-personal" className="mb-6">
                      <h4 className="font-medium mb-3 text-gray-700">Información Personal</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-2">
                          <Label htmlFor="full_name">Nombre Completo *</Label>
                          <Input
                            id="full_name"
                            value={newPatient.full_name}
                            onChange={(e) => setNewPatient({...newPatient, full_name: e.target.value})}
                            required
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="birth_date">Fecha de Nacimiento</Label>
                          <Input
                            id="birth_date"
                            type="date"
                            value={newPatient.birth_date}
                            onChange={(e) => setNewPatient({...newPatient, birth_date: e.target.value})}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="birth_place">Lugar de Nacimiento</Label>
                          <Input
                            id="birth_place"
                            value={newPatient.birth_place}
                            onChange={(e) => setNewPatient({...newPatient, birth_place: e.target.value})}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="age_years">Edad (Años)</Label>
                          <Input
                            id="age_years"
                            type="number"
                            value={newPatient.age_years}
                            onChange={(e) => setNewPatient({...newPatient, age_years: e.target.value})}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="age_months">Edad (Meses)</Label>
                          <Input
                            id="age_months"
                            type="number"
                            value={newPatient.age_months}
                            onChange={(e) => setNewPatient({...newPatient, age_months: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Información de Contacto */}
                    <div id="info-contacto" className="mb-6">
                      <h4 className="font-medium mb-3 text-gray-700">Información de Contacto</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Teléfono</Label>
                          <Input
                            id="phone"
                            value={newPatient.phone}
                            onChange={(e) => setNewPatient({...newPatient, phone: e.target.value})}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={newPatient.email}
                            onChange={(e) => setNewPatient({...newPatient, email: e.target.value})}
                          />
                        </div>
                        
                        <div className="col-span-2">
                          <Label htmlFor="address">Dirección</Label>
                          <Input
                            id="address"
                            value={newPatient.address}
                            onChange={(e) => setNewPatient({...newPatient, address: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Contacto de Emergencia */}
                    <div id="emergencia" className="mb-6">
                      <h4 className="font-medium mb-3 text-gray-700">Contacto de Emergencia</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="emergency_contact_name">Nombre del Contacto</Label>
                          <Input
                            id="emergency_contact_name"
                            value={newPatient.emergency_contact_name}
                            onChange={(e) => setNewPatient({...newPatient, emergency_contact_name: e.target.value})}
                          />
                        </div>
                        
                        <div>
                          <Label htmlFor="emergency_contact_phone">Teléfono de Emergencia</Label>
                          <Input
                            id="emergency_contact_phone"
                            value={newPatient.emergency_contact_phone}
                            onChange={(e) => setNewPatient({...newPatient, emergency_contact_phone: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="sticky bottom-0 bg-white pt-4 border-t">
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsAddingPatient(false)}>
                          Cancelar
                        </Button>
                        <Button type="submit">Guardar Paciente</Button>
                      </DialogFooter>
                    </div>
                  </form>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pacientes</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pacientes Activos</CardTitle>
              <Users className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{patients.filter(p => p.status === 'active').length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Nuevos Este Mes</CardTitle>
              <Users className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {patients.filter(p => {
                  const createdAt = new Date(p.created_at);
                  const now = new Date();
                  return createdAt.getMonth() === now.getMonth() && createdAt.getFullYear() === now.getFullYear();
                }).length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar pacientes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filtrar por estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="active">Activos</SelectItem>
              <SelectItem value="inactive">Inactivos</SelectItem>
              <SelectItem value="discharged">Alta médica</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Patients List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPatients.map((patient) => (
            <Card key={patient.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{patient.full_name}</CardTitle>
                    <p className="text-sm text-gray-600">Edad: {getAge(patient)}</p>
                  </div>
                  <Select 
                    value={patient.status} 
                    onValueChange={(value) => updatePatientStatus(patient.id, value as 'active' | 'inactive' | 'discharged')}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Activo</SelectItem>
                      <SelectItem value="inactive">Inactivo</SelectItem>
                      <SelectItem value="discharged">Dado de Alta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  {patient.phone && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Teléfono:</span>
                      <span>{patient.phone}</span>
                    </div>
                  )}
                  {patient.email && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Email:</span>
                      <span className="truncate">{patient.email}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Creado:</span>
                    <span>{new Date(patient.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Link to={`/clinical-history/${patient.id}`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full">
                      <FileText className="h-4 w-4 mr-1" />
                      Historia
                    </Button>
                  </Link>
                  <Link to={`/sessions/${patient.id}`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full">
                      <Calendar className="h-4 w-4 mr-1" />
                      Sesiones
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredPatients.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No hay pacientes</h3>
            <p className="text-gray-600 mb-4">
              {searchTerm || statusFilter !== 'all' 
                ? 'No se encontraron pacientes con los filtros seleccionados.' 
                : 'Comience agregando su primer paciente.'}
            </p>
            {(!searchTerm && statusFilter === 'all') && (
              <Button onClick={() => setIsAddingPatient(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Agregar Primer Paciente
              </Button>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}