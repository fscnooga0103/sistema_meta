import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, AlignmentType } from 'docx';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';

export interface ClinicalHistoryData {
  patient: {
    name: string;
    age: number;
    gender: string;
    phone: string;
    email: string;
    address: string;
    emergencyContact: string;
    emergencyPhone: string;
  };
  personalHistory: {
    birthDate: string;
    birthPlace: string;
    maritalStatus: string;
    education: string;
    occupation: string;
    religion: string;
  };
  familyHistory: {
    father: string;
    mother: string;
    siblings: string;
    psychiatricHistory: string;
    medicalHistory: string;
  };
  medicalHistory: {
    allergies: string;
    medications: string;
    surgeries: string;
    chronicIllnesses: string;
    hospitalizations: string;
  };
  psychologicalHistory: {
    previousTreatments: string;
    medications: string;
    traumaticEvents: string;
    substanceUse: string;
    currentSymptoms: string;
  };
  mentalStatusExam: {
    appearance: string;
    behavior: string;
    speech: string;
    mood: string;
    affect: string;
    thoughtProcess: string;
    thoughtContent: string;
    perception: string;
    cognition: string;
    insight: string;
    judgment: string;
  };
  diagnosis: {
    primary: string;
    secondary: string;
    differential: string;
  };
  treatmentPlan: {
    goals: string;
    interventions: string;
    frequency: string;
    duration: string;
  };
  createdAt: string;
  psychologist: string;
}

export interface SessionReportData {
  patient: {
    name: string;
    age: number;
  };
  sessions: Array<{
    date: string;
    duration: number;
    objectives: string;
    activities: string;
    progress: string;
    observations: string;
    nextSession: string;
  }>;
  summary: {
    totalSessions: number;
    averageDuration: number;
    overallProgress: string;
  };
  psychologist: string;
  generatedAt: string;
}

export interface FinancialReportData {
  period: {
    start: string;
    end: string;
  };
  transactions: Array<{
    date: string;
    patient: string;
    service: string;
    amount: number;
    status: string;
    paymentMethod: string;
  }>;
  summary: {
    totalIncome: number;
    totalSessions: number;
    averageSessionValue: number;
    pendingPayments: number;
  };
  psychologist: string;
  generatedAt: string;
}

export const exportClinicalHistoryToDocx = async (data: ClinicalHistoryData) => {
  const doc = new Document({
    sections: [
      {
        properties: {},
        children: [
          new Paragraph({
            text: "HISTORIA CLÍNICA PSICOLÓGICA",
            heading: HeadingLevel.TITLE,
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({ text: "" }),
          
          // Patient Information
          new Paragraph({
            text: "DATOS DEL PACIENTE",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Nombre: ", bold: true }),
              new TextRun({ text: data.patient.name }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Edad: ", bold: true }),
              new TextRun({ text: data.patient.age.toString() + " años" }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Género: ", bold: true }),
              new TextRun({ text: data.patient.gender }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Teléfono: ", bold: true }),
              new TextRun({ text: data.patient.phone }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Email: ", bold: true }),
              new TextRun({ text: data.patient.email }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Dirección: ", bold: true }),
              new TextRun({ text: data.patient.address }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Contacto de Emergencia: ", bold: true }),
              new TextRun({ text: data.patient.emergencyContact + " - " + data.patient.emergencyPhone }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Personal History
          new Paragraph({
            text: "ANTECEDENTES PERSONALES",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Fecha de Nacimiento: ", bold: true }),
              new TextRun({ text: data.personalHistory.birthDate }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Lugar de Nacimiento: ", bold: true }),
              new TextRun({ text: data.personalHistory.birthPlace }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Estado Civil: ", bold: true }),
              new TextRun({ text: data.personalHistory.maritalStatus }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Educación: ", bold: true }),
              new TextRun({ text: data.personalHistory.education }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Ocupación: ", bold: true }),
              new TextRun({ text: data.personalHistory.occupation }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Religión: ", bold: true }),
              new TextRun({ text: data.personalHistory.religion }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Family History
          new Paragraph({
            text: "ANTECEDENTES FAMILIARES",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Padre: ", bold: true }),
              new TextRun({ text: data.familyHistory.father }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Madre: ", bold: true }),
              new TextRun({ text: data.familyHistory.mother }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Hermanos: ", bold: true }),
              new TextRun({ text: data.familyHistory.siblings }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Antecedentes Psiquiátricos: ", bold: true }),
              new TextRun({ text: data.familyHistory.psychiatricHistory }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Antecedentes Médicos: ", bold: true }),
              new TextRun({ text: data.familyHistory.medicalHistory }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Medical History
          new Paragraph({
            text: "HISTORIA MÉDICA",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Alergias: ", bold: true }),
              new TextRun({ text: data.medicalHistory.allergies }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Medicamentos: ", bold: true }),
              new TextRun({ text: data.medicalHistory.medications }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Cirugías: ", bold: true }),
              new TextRun({ text: data.medicalHistory.surgeries }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Enfermedades Crónicas: ", bold: true }),
              new TextRun({ text: data.medicalHistory.chronicIllnesses }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Hospitalizaciones: ", bold: true }),
              new TextRun({ text: data.medicalHistory.hospitalizations }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Psychological History
          new Paragraph({
            text: "HISTORIA PSICOLÓGICA",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Tratamientos Previos: ", bold: true }),
              new TextRun({ text: data.psychologicalHistory.previousTreatments }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Medicamentos Psiquiátricos: ", bold: true }),
              new TextRun({ text: data.psychologicalHistory.medications }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Eventos Traumáticos: ", bold: true }),
              new TextRun({ text: data.psychologicalHistory.traumaticEvents }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Uso de Sustancias: ", bold: true }),
              new TextRun({ text: data.psychologicalHistory.substanceUse }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Síntomas Actuales: ", bold: true }),
              new TextRun({ text: data.psychologicalHistory.currentSymptoms }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Mental Status Exam
          new Paragraph({
            text: "EXAMEN DEL ESTADO MENTAL",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Apariencia: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.appearance }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Comportamiento: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.behavior }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Habla: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.speech }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Estado de Ánimo: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.mood }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Afecto: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.affect }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Proceso de Pensamiento: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.thoughtProcess }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Contenido del Pensamiento: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.thoughtContent }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Percepción: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.perception }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Cognición: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.cognition }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Insight: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.insight }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Juicio: ", bold: true }),
              new TextRun({ text: data.mentalStatusExam.judgment }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Diagnosis
          new Paragraph({
            text: "DIAGNÓSTICO",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Diagnóstico Primario: ", bold: true }),
              new TextRun({ text: data.diagnosis.primary }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Diagnóstico Secundario: ", bold: true }),
              new TextRun({ text: data.diagnosis.secondary }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Diagnóstico Diferencial: ", bold: true }),
              new TextRun({ text: data.diagnosis.differential }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Treatment Plan
          new Paragraph({
            text: "PLAN DE TRATAMIENTO",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Objetivos: ", bold: true }),
              new TextRun({ text: data.treatmentPlan.goals }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Intervenciones: ", bold: true }),
              new TextRun({ text: data.treatmentPlan.interventions }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Frecuencia: ", bold: true }),
              new TextRun({ text: data.treatmentPlan.frequency }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Duración: ", bold: true }),
              new TextRun({ text: data.treatmentPlan.duration }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Footer
          new Paragraph({ text: "" }),
          new Paragraph({
            children: [
              new TextRun({ text: "Psicólogo: ", bold: true }),
              new TextRun({ text: data.psychologist }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Fecha de Creación: ", bold: true }),
              new TextRun({ text: new Date(data.createdAt).toLocaleDateString('es-ES') }),
            ],
          }),
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  saveAs(blob, `Historia_Clinica_${data.patient.name.replace(/\s+/g, '_')}.docx`);
};

export const exportSessionReportToDocx = async (data: SessionReportData) => {
  const doc = new Document({
    sections: [
      {
        properties: {},
        children: [
          new Paragraph({
            text: "REPORTE DE SESIONES",
            heading: HeadingLevel.TITLE,
            alignment: AlignmentType.CENTER,
          }),
          new Paragraph({ text: "" }),
          
          // Patient Information
          new Paragraph({
            text: "INFORMACIÓN DEL PACIENTE",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Paciente: ", bold: true }),
              new TextRun({ text: data.patient.name }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Edad: ", bold: true }),
              new TextRun({ text: data.patient.age.toString() + " años" }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Sessions Summary
          new Paragraph({
            text: "RESUMEN DE SESIONES",
            heading: HeadingLevel.HEADING_1,
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Total de Sesiones: ", bold: true }),
              new TextRun({ text: data.summary.totalSessions.toString() }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Duración Promedio: ", bold: true }),
              new TextRun({ text: data.summary.averageDuration.toString() + " minutos" }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Progreso General: ", bold: true }),
              new TextRun({ text: data.summary.overallProgress }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Sessions Detail
          new Paragraph({
            text: "DETALLE DE SESIONES",
            heading: HeadingLevel.HEADING_1,
          }),
          
          ...data.sessions.map((session, index) => [
            new Paragraph({
              text: `SESIÓN ${index + 1}`,
              heading: HeadingLevel.HEADING_2,
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Fecha: ", bold: true }),
                new TextRun({ text: new Date(session.date).toLocaleDateString('es-ES') }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Duración: ", bold: true }),
                new TextRun({ text: session.duration.toString() + " minutos" }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Objetivos: ", bold: true }),
                new TextRun({ text: session.objectives }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Actividades: ", bold: true }),
                new TextRun({ text: session.activities }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Progreso: ", bold: true }),
                new TextRun({ text: session.progress }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Observaciones: ", bold: true }),
                new TextRun({ text: session.observations }),
              ],
            }),
            new Paragraph({
              children: [
                new TextRun({ text: "Próxima Sesión: ", bold: true }),
                new TextRun({ text: session.nextSession }),
              ],
            }),
            new Paragraph({ text: "" }),
          ]).flat(),

          // Footer
          new Paragraph({ text: "" }),
          new Paragraph({
            children: [
              new TextRun({ text: "Psicólogo: ", bold: true }),
              new TextRun({ text: data.psychologist }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({ text: "Fecha de Generación: ", bold: true }),
              new TextRun({ text: new Date(data.generatedAt).toLocaleDateString('es-ES') }),
            ],
          }),
        ],
      },
    ],
  });

  const buffer = await Packer.toBuffer(doc);
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  saveAs(blob, `Reporte_Sesiones_${data.patient.name.replace(/\s+/g, '_')}.docx`);
};

export const exportFinancialReportToXlsx = (data: FinancialReportData) => {
  const workbook = XLSX.utils.book_new();

  // Summary Sheet
  const summaryData = [
    ['REPORTE FINANCIERO'],
    [''],
    ['Período:', `${data.period.start} - ${data.period.end}`],
    ['Psicólogo:', data.psychologist],
    ['Fecha de Generación:', new Date(data.generatedAt).toLocaleDateString('es-ES')],
    [''],
    ['RESUMEN'],
    ['Total de Ingresos:', `$${data.summary.totalIncome.toFixed(2)}`],
    ['Total de Sesiones:', data.summary.totalSessions],
    ['Valor Promedio por Sesión:', `$${data.summary.averageSessionValue.toFixed(2)}`],
    ['Pagos Pendientes:', `$${data.summary.pendingPayments.toFixed(2)}`],
  ];

  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Resumen');

  // Transactions Sheet
  const transactionHeaders = ['Fecha', 'Paciente', 'Servicio', 'Monto', 'Estado', 'Método de Pago'];
  const transactionData = [
    transactionHeaders,
    ...data.transactions.map(transaction => [
      new Date(transaction.date).toLocaleDateString('es-ES'),
      transaction.patient,
      transaction.service,
      transaction.amount,
      transaction.status,
      transaction.paymentMethod
    ])
  ];

  const transactionSheet = XLSX.utils.aoa_to_sheet(transactionData);
  XLSX.utils.book_append_sheet(workbook, transactionSheet, 'Transacciones');

  // Monthly Summary Sheet
  const monthlyData = data.transactions.reduce((acc, transaction) => {
    const month = new Date(transaction.date).toLocaleDateString('es-ES', { year: 'numeric', month: 'long' });
    if (!acc[month]) {
      acc[month] = { income: 0, sessions: 0 };
    }
    acc[month].income += transaction.amount;
    acc[month].sessions += 1;
    return acc;
  }, {} as Record<string, { income: number; sessions: number }>);

  const monthlySummaryData = [
    ['Mes', 'Ingresos', 'Sesiones'],
    ...Object.entries(monthlyData).map(([month, data]) => [
      month,
      data.income,
      data.sessions
    ])
  ];

  const monthlySheet = XLSX.utils.aoa_to_sheet(monthlySummaryData);
  XLSX.utils.book_append_sheet(workbook, monthlySheet, 'Resumen Mensual');

  const fileName = `Reporte_Financiero_${data.period.start.replace(/\//g, '-')}_${data.period.end.replace(/\//g, '-')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
};