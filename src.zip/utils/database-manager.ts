// Database Manager for PsicoManager
// Manages private data storage for each psychologist profile

export interface DatabaseConfig {
  userId: string;
  storagePrefix: string;
}

export class DatabaseManager {
  private config: DatabaseConfig;

  constructor(config: DatabaseConfig) {
    this.config = config;
  }

  // Generate unique storage key for user data
  private getStorageKey(dataType: string): string {
    return `${this.config.storagePrefix}_${dataType}_${this.config.userId}`;
  }

  // Store data securely for the user
  async storeUserData<T>(dataType: string, data: T): Promise<void> {
    try {
      const key = this.getStorageKey(dataType);
      const encryptedData = this.encryptData(JSON.stringify(data));
      localStorage.setItem(key, encryptedData);
    } catch (error) {
      console.error(`Error storing ${dataType}:`, error);
      throw new Error(`Failed to store ${dataType}`);
    }
  }

  // Retrieve data securely for the user
  async getUserData<T>(dataType: string): Promise<T | null> {
    try {
      const key = this.getStorageKey(dataType);
      const encryptedData = localStorage.getItem(key);
      
      if (!encryptedData) return null;
      
      const decryptedData = this.decryptData(encryptedData);
      return JSON.parse(decryptedData);
    } catch (error) {
      console.error(`Error retrieving ${dataType}:`, error);
      return null;
    }
  }

  // Delete user data
  async deleteUserData(dataType: string): Promise<void> {
    try {
      const key = this.getStorageKey(dataType);
      localStorage.removeItem(key);
    } catch (error) {
      console.error(`Error deleting ${dataType}:`, error);
      throw new Error(`Failed to delete ${dataType}`);
    }
  }

  // List all data types for user
  getUserDataTypes(): string[] {
    const prefix = `${this.config.storagePrefix}_`;
    const suffix = `_${this.config.userId}`;
    const keys = Object.keys(localStorage);
    
    return keys
      .filter(key => key.startsWith(prefix) && key.endsWith(suffix))
      .map(key => {
        const withoutPrefix = key.substring(prefix.length);
        return withoutPrefix.substring(0, withoutPrefix.length - suffix.length);
      });
  }

  // Basic encryption/decryption (for demo purposes)
  // In production, use proper encryption libraries
  private encryptData(data: string): string {
    // Simple base64 encoding for demo
    // In production, use proper encryption
    return btoa(encodeURIComponent(data));
  }

  private decryptData(encryptedData: string): string {
    // Simple base64 decoding for demo
    // In production, use proper decryption
    try {
      return decodeURIComponent(atob(encryptedData));
    } catch (error) {
      throw new Error('Failed to decrypt data');
    }
  }

  // Backup user data
  async backupUserData(): Promise<string> {
    const dataTypes = this.getUserDataTypes();
    const backup: Record<string, unknown> = {};

    for (const dataType of dataTypes) {
      backup[dataType] = await this.getUserData(dataType);
    }

    return JSON.stringify({
      userId: this.config.userId,
      timestamp: new Date().toISOString(),
      data: backup
    });
  }

  // Restore user data from backup
  async restoreUserData(backupString: string): Promise<void> {
    try {
      const backup = JSON.parse(backupString);
      
      if (backup.userId !== this.config.userId) {
        throw new Error('Backup does not match current user');
      }

      for (const [dataType, data] of Object.entries(backup.data)) {
        if (data !== null) {
          await this.storeUserData(dataType, data);
        }
      }
    } catch (error) {
      console.error('Error restoring backup:', error);
      throw new Error('Failed to restore backup');
    }
  }

  // Clear all user data (for privacy/security)
  async clearAllUserData(): Promise<void> {
    const dataTypes = this.getUserDataTypes();
    
    for (const dataType of dataTypes) {
      await this.deleteUserData(dataType);
    }
  }

  // Get storage usage statistics
  getStorageStats(): {
    totalKeys: number;
    userKeys: number;
    approximateSize: number;
  } {
    const allKeys = Object.keys(localStorage);
    const userKeys = this.getUserDataTypes();
    
    let approximateSize = 0;
    userKeys.forEach(dataType => {
      const key = this.getStorageKey(dataType);
      const data = localStorage.getItem(key);
      if (data) {
        approximateSize += data.length * 2; // Rough estimate in bytes
      }
    });

    return {
      totalKeys: allKeys.length,
      userKeys: userKeys.length,
      approximateSize
    };
  }
}

// Factory function to create database manager for current user
export const createUserDatabase = (userId: string): DatabaseManager => {
  return new DatabaseManager({
    userId,
    storagePrefix: 'psicoManager'
  });
};

// Singleton instance for current session
let currentDatabase: DatabaseManager | null = null;

export const getCurrentDatabase = (userId: string): DatabaseManager => {
  if (!currentDatabase || currentDatabase['config'].userId !== userId) {
    currentDatabase = createUserDatabase(userId);
  }
  return currentDatabase;
};